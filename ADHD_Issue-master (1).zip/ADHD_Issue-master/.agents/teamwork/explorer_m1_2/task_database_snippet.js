    const taskDatabase = {
      // #01. Toán (Grade 1): Cộng số chim trên cành (Phép cộng phạm vi 10)
      'G1_MATH_01':   "id": "G1_MATH_01",
        "grade": 1,
        "subject": "Toán",
        "cat": "math",
        "catName": "Toán GDPT 2018",
        "icon": "🐦",
        "title": "Cộng số chim trên cành (Phép cộng phạm vi 10)",
        "island": "study",
        "reward": 120,
        "stepSeconds": 60,
        "original_text": "Trên cành cây có 5 con chim đang đậu. Lát sau có thêm 3 con chim nữa bay đến đậu cùng. Hỏi trên cành cây lúc này có tất cả bao nhiêu con chim?",
        "final_answer": {
                "value": 8,
                "unit": "con chim",
                "normalized_display": "8 con chim",
                "acceptable_variants": [
                        "8",
                        "8 con",
                        "8 con chim"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Trẻ dễ bị xao nhãng bởi từ ngữ miêu tả 'cành cây', 'bay đến' và quên mất số lượng ban đầu.",
                "executive_function_scaffolding": "Tách từ khóa hành động 'thêm' để kích hoạt phép cộng đơn bước.",
                "visual_or_concrete_aid": "Biểu tượng 5 chấm tròn màu xanh + 3 chấm tròn màu đỏ trên màn hình."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Tìm Dữ Kiện",
                        "action_verb": "Gạch_chân",
                        "atomic_instruction": "Gạch chân 2 số lượng chim trong đề bài.",
                        "text": "Gạch chân 2 số lượng chim trong đề bài.",
                        "type": "highlight",
                        "ui_type": "highlight",
                        "ui_data": {
                                "prompt_text": "Tìm số lượng chim ban đầu và số chim bay đến thêm:",
                                "highlight_target_segments": [
                                        "5 con chim",
                                        "3 con chim"
                                ]
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "Chú ý số chim ban đầu và số chim bay đến thêm."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": [
                                        "5 con chim",
                                        "3 con chim"
                                ],
                                "feedback_on_error": "Milo cùng con tìm 2 số lượng chim nhé!"
                        },
                        "mathematical_or_logical_goal": "Nhận diện dữ kiện đã cho",
                        "intermediate_output": "Ban đầu: 5 con; thêm vào: 3 con",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Chọn Phép Tính",
                        "action_verb": "Chọn",
                        "atomic_instruction": "Chọn phép tính để tìm tổng số chim.",
                        "text": "Chọn phép tính để tìm tổng số chim.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Có thêm chim bay đến, ta dùng phép tính nào?",
                                "options": [
                                        "5 + 3",
                                        "5 - 3"
                                ]
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "Có thêm thì chúng mình làm phép tính cộng nha."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "5 + 3",
                                "feedback_on_error": "Thêm vào thì mình làm phép tính cộng con nhé!"
                        },
                        "mathematical_or_logical_goal": "Lựa chọn toán tử đại số (phép cộng)",
                        "intermediate_output": "5 + 3",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Tính Kết Quả",
                        "action_verb": "Tính",
                        "atomic_instruction": "Tính kết quả 5 cộng 3 bằng bao nhiêu.",
                        "text": "Tính kết quả 5 cộng 3 bằng bao nhiêu.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "5 + 3 = ?",
                                "placeholder": "Nhập số chim..."
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 40
                        },
                        "hints": [
                                "Đếm thêm 3 ngón tay từ 5: 6, 7, 8!"
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "8",
                                "feedback_on_error": "5 cộng thêm 3 bằng 8 con chim nhé!"
                        },
                        "mathematical_or_logical_goal": "Tính toán và kết luận kèm danh số",
                        "intermediate_output": "8 con chim",
                        "is_final_step": true
                }
        ]
},

      // #02. Toán (Grade 1): Tính số cam còn lại của mẹ (Phép trừ phạm vi 20)
      'G1_MATH_02':   "id": "G1_MATH_02",
        "grade": 1,
        "subject": "Toán",
        "cat": "math",
        "catName": "Toán GDPT 2018",
        "icon": "🍊",
        "title": "Tính số cam còn lại của mẹ (Phép trừ phạm vi 20)",
        "island": "study",
        "reward": 120,
        "stepSeconds": 60,
        "original_text": "Mẹ mua về 18 quả cam. Cả nhà đã ăn hết 6 quả cam. Hỏi mẹ còn lại bao nhiêu quả cam?",
        "final_answer": {
                "value": 12,
                "unit": "quả cam",
                "normalized_display": "12 quả cam",
                "acceptable_variants": [
                        "12",
                        "12 quả",
                        "12 quả cam"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Hay nhầm lẫn giữa phép tính cộng và trừ khi đọc lướt qua từ 'còn lại'.",
                "executive_function_scaffolding": "Khóa sự chú ý vào hành động 'đã ăn hết' mang ý nghĩa bớt đi.",
                "visual_or_concrete_aid": "Bảng cấu tạo số tách 18 thành 10 và 8; gạch bỏ 6 đơn vị từ 8."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Xác Định Dữ Kiện",
                        "action_verb": "Đọc",
                        "atomic_instruction": "Đọc số cam ban đầu và số cam đã ăn.",
                        "text": "Đọc số cam ban đầu và số cam đã ăn.",
                        "type": "highlight",
                        "ui_type": "highlight",
                        "ui_data": {
                                "prompt_text": "Mẹ mua 18 quả cam, cả nhà ăn hết 6 quả:",
                                "highlight_target_segments": [
                                        "18 quả cam",
                                        "6 quả cam"
                                ]
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "Tìm số 18 và số 6 trong câu chuyện nhé."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": [
                                        "18 quả cam",
                                        "6 quả cam"
                                ],
                                "feedback_on_error": "Cùng Milo nhìn 2 con số 18 và 6 nào!"
                        },
                        "mathematical_or_logical_goal": "Trích xuất dữ kiện đầu vào",
                        "intermediate_output": "Có: 18 quả; Đã ăn: 6 quả",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Thiết Lập Phép Tính",
                        "action_verb": "Chọn",
                        "atomic_instruction": "Chọn phép trừ để tìm số cam còn lại.",
                        "text": "Chọn phép trừ để tìm số cam còn lại.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Đã ăn bớt đi thì làm phép tính gì?",
                                "options": [
                                        "18 - 6",
                                        "18 + 6"
                                ]
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "Ăn hết là bớt đi, ta làm phép trừ."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "18 - 6",
                                "feedback_on_error": "Ăn bớt đi là phép trừ nha con!"
                        },
                        "mathematical_or_logical_goal": "Thiết lập phép trừ",
                        "intermediate_output": "18 - 6",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Tính Đáp Số",
                        "action_verb": "Tính",
                        "atomic_instruction": "Tính nhẩm hàng đơn vị 8 trừ 6 để ra kết quả.",
                        "text": "Tính nhẩm hàng đơn vị 8 trừ 6 để ra kết quả.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "18 - 6 = ?",
                                "placeholder": "Nhập số cam còn lại..."
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 40
                        },
                        "hints": [
                                "8 trừ 6 bằng 2, giữ nguyên 1 chục là 12."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "12",
                                "feedback_on_error": "8 trừ 6 bằng 2, thêm 1 chục là 12 quả cam!"
                        },
                        "mathematical_or_logical_goal": "Tính toán số học 2 chữ số trừ 1 chữ số",
                        "intermediate_output": "12 quả cam",
                        "is_final_step": true
                }
        ]
},

      // #03. Tiếng Việt (Grade 1): Đọc hiểu: Ai cất tiếng gáy vang buổi sáng?
      'G1_VIET_03':   "id": "G1_VIET_03",
        "grade": 1,
        "subject": "Tiếng Việt",
        "cat": "viet",
        "catName": "Tiếng Việt GDPT",
        "icon": "🐓",
        "title": "Đọc hiểu: Ai cất tiếng gáy vang buổi sáng?",
        "island": "study",
        "reward": 120,
        "stepSeconds": 70,
        "original_text": "Đọc đoạn văn sau và trả lời câu hỏi: 'Buổi sáng sớm, chú gà trống cất tiếng gáy vang báo hiệu ngày mới. Mặt trời từ từ nhô lên đỏ rực. Bé Mai thức dậy, đánh răng, rửa mặt rồi vui vẻ cùng mẹ đi bộ đến trường tiểu học.'\nCâu hỏi: Ai là người cất tiếng gáy vang vào buổi sáng sớm?",
        "final_answer": {
                "value": "chú gà trống",
                "unit": null,
                "normalized_display": "chú gà trống",
                "acceptable_variants": [
                        "chú gà trống",
                        "gà trống",
                        "Chú gà trống",
                        "con gà trống"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Trẻ bị thu hút bởi tên nhân vật người 'Bé Mai' ở câu cuối mà vội vã chọn Mai thay vì gà trống.",
                "executive_function_scaffolding": "Chỉ dẫn đọc dò từng dòng (Line-by-line reading mask).",
                "visual_or_concrete_aid": "Tô đậm màu vàng cụm từ 'cất tiếng gáy vang' trong câu 1."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Dò Tìm Từ Khóa",
                        "action_verb": "Gạch_chân",
                        "atomic_instruction": "Gạch chân cụm từ cất tiếng gáy vang trong bài.",
                        "text": "Gạch chân cụm từ cất tiếng gáy vang trong bài.",
                        "type": "highlight",
                        "ui_type": "highlight",
                        "ui_data": {
                                "prompt_text": "Tìm cụm từ gáy vang trong câu đầu tiên:",
                                "highlight_target_segments": [
                                        "cất tiếng gáy vang"
                                ]
                        },
                        "duration_sec": 70,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "Nhìn vào dòng thứ nhất của câu chuyện nhé."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": [
                                        "cất tiếng gáy vang"
                                ],
                                "feedback_on_error": "Con tìm cụm từ cất tiếng gáy vang ở dòng đầu nha!"
                        },
                        "mathematical_or_logical_goal": "Định vị từ khóa mục tiêu",
                        "intermediate_output": "Cụm từ khóa: 'cất tiếng gáy vang'",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Tìm Nhân Vật",
                        "action_verb": "Dò",
                        "atomic_instruction": "Dò tìm nhân vật đứng trước cụm từ vừa gạch.",
                        "text": "Dò tìm nhân vật đứng trước cụm từ vừa gạch.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Ai là người thực hiện hành động cất tiếng gáy vang?",
                                "options": [
                                        "chú gà trống",
                                        "Bé Mai",
                                        "Mặt trời"
                                ]
                        },
                        "duration_sec": 70,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "Con vật nào cất tiếng gáy ò ó o mỗi sáng?"
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "chú gà trống",
                                "feedback_on_error": "Đó chính là chú gà trống đấy con!"
                        },
                        "mathematical_or_logical_goal": "Đối chiếu ngữ cảnh",
                        "intermediate_output": "'chú gà trống cất tiếng gáy vang'",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Ghi Đáp Án",
                        "action_verb": "Chọn",
                        "atomic_instruction": "Chọn đúng tên chú gà trống cất tiếng gáy.",
                        "text": "Chọn đúng tên chú gà trống cất tiếng gáy.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Đáp án cuối cùng cho câu hỏi là:",
                                "options": [
                                        "chú gà trống",
                                        "Bé Mai"
                                ]
                        },
                        "duration_sec": 70,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 40
                        },
                        "hints": [
                                "Chọn chú gà trống để hoàn thành bài nhé."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "chú gà trống",
                                "feedback_on_error": "Đáp án đúng là chú gà trống nha!"
                        },
                        "mathematical_or_logical_goal": "Trích xuất câu trả lời trực tiếp",
                        "intermediate_output": "chú gà trống",
                        "is_final_step": true
                }
        ]
},

      // #04. Khoa học & Tự nhiên xã hội (Grade 1): Đếm số hình tròn trên mô hình ngôi nhà
      'G1_MCQ_04':   "id": "G1_MCQ_04",
        "grade": 1,
        "subject": "Khoa học & Tự nhiên xã hội",
        "cat": "math",
        "catName": "TNXH & Hình Học",
        "icon": "🏠",
        "title": "Đếm số hình tròn trên mô hình ngôi nhà",
        "island": "study",
        "reward": 110,
        "stepSeconds": 60,
        "original_text": "Hình vẽ một ngôi nhà gồm: một mái nhà hình tam giác, thân nhà hình chữ nhật, một cửa chính hình chữ nhật và hai cửa sổ hình tròn. Hỏi ngôi nhà đó có bao nhiêu hình tròn?\nA. 1 hình tròn\nB. 2 hình tròn\nC. 3 hình tròn\nD. 4 hình tròn",
        "final_answer": {
                "value": "B",
                "unit": null,
                "normalized_display": "B. 2 hình tròn",
                "acceptable_variants": [
                        "B",
                        "B.",
                        "2 hình tròn",
                        "2",
                        "B. 2 hình tròn"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Xu hướng hấp tấp chọn số 1 vì nhìn thấy số 'một' xuất hiện đầu tiên trong đề bài.",
                "executive_function_scaffolding": "Buộc trẻ xác nhận tiêu chí lọc 'hình tròn' trước khi nhìn vào các đáp án A/B/C/D.",
                "visual_or_concrete_aid": "Hình ảnh trực quan khoanh tròn hai cửa sổ."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Xác Định Hình",
                        "action_verb": "Xác_định",
                        "atomic_instruction": "Xác định câu hỏi yêu cầu đếm hình gì.",
                        "text": "Xác định câu hỏi yêu cầu đếm hình gì.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Đề bài yêu cầu đếm loại hình học nào?",
                                "options": [
                                        "Hình tròn",
                                        "Hình tam giác",
                                        "Hình chữ nhật"
                                ]
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Đề bài hỏi: có mấy hình tròn nhé con."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "Hình tròn",
                                "feedback_on_error": "Chúng mình cần đếm hình tròn con nha!"
                        },
                        "mathematical_or_logical_goal": "Xác định hình tiêu điểm",
                        "intermediate_output": "Hình tiêu điểm: hình tròn",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Đếm Cửa Sổ",
                        "action_verb": "Đếm",
                        "atomic_instruction": "Đếm số lượng cửa sổ tròn trong mô tả.",
                        "text": "Đếm số lượng cửa sổ tròn trong mô tả.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Trong mô tả có mấy cửa sổ hình tròn?",
                                "options": [
                                        "2 cửa sổ hình tròn",
                                        "1 cửa sổ",
                                        "3 cửa sổ"
                                ]
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Đọc kỹ câu: 'hai cửa sổ hình tròn'."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "2 cửa sổ hình tròn",
                                "feedback_on_error": "Có 2 cửa sổ hình tròn trong ngôi nhà!"
                        },
                        "mathematical_or_logical_goal": "Quét văn bản tìm cặp (thuộc tính, số lượng)",
                        "intermediate_output": "'hai cửa sổ hình tròn' -> 2",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Chọn Phương Án",
                        "action_verb": "Chọn",
                        "atomic_instruction": "Chọn phương án B có 2 hình tròn.",
                        "text": "Chọn phương án B có 2 hình tròn.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Chọn phương án đúng nhất:",
                                "options": [
                                        "A. 1 hình tròn",
                                        "B. 2 hình tròn",
                                        "C. 3 hình tròn",
                                        "D. 4 hình tròn"
                                ]
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 40
                        },
                        "hints": [
                                "Chọn phương án B. 2 hình tròn."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "B. 2 hình tròn",
                                "feedback_on_error": "Phương án B là đáp án chính xác!"
                        },
                        "mathematical_or_logical_goal": "Khẳng định phương án đúng",
                        "intermediate_output": "Phương án B",
                        "is_final_step": true
                }
        ]
},

      // #05. Tiếng Anh (Grade 1): English Vocabulary: Màu sắc của cây bút chì (Colors)
      'G1_ENG_05':   "id": "G1_ENG_05",
        "grade": 1,
        "subject": "Tiếng Anh",
        "cat": "eng",
        "catName": "Tiếng Anh Tiểu Học",
        "icon": "✏️",
        "title": "English Vocabulary: Màu sắc của cây bút chì (Colors)",
        "island": "study",
        "reward": 120,
        "stepSeconds": 60,
        "original_text": "Choose the correct word to complete the sentence:\n'Look at my new pencil. It is ______.' (Màu đỏ)\nA. blue\nB. green\nC. red\nD. yellow",
        "final_answer": {
                "value": "C",
                "unit": null,
                "normalized_display": "C. red",
                "acceptable_variants": [
                        "C",
                        "C.",
                        "red",
                        "C. red"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Nhầm lẫn giữa các từ màu sắc bắt đầu bằng phụ âm tương tự hoặc màu quen thuộc.",
                "executive_function_scaffolding": "Liên kết từ với thẻ màu mẫu trực quan.",
                "visual_or_concrete_aid": "Thẻ màu đỏ kèm chữ cái gợi ý âm đầu 'r-'."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Đọc Gợi Ý",
                        "action_verb": "Đọc",
                        "atomic_instruction": "Đọc từ tiếng Việt chỉ màu đỏ trong ngoặc.",
                        "text": "Đọc từ tiếng Việt chỉ màu đỏ trong ngoặc.",
                        "type": "checkbox",
                        "ui_type": "checkbox",
                        "ui_data": {
                                "prompt_text": "Con có thấy từ '(Màu đỏ)' ở cuối câu không?",
                                "options": [
                                        "Đã thấy từ Màu đỏ"
                                ]
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "Nhìn vào chữ trong dấu ngoặc đơn nhé."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": true,
                                "feedback_on_error": "Milo chỉ cho con chữ (Màu đỏ) ở cuối câu nhé!"
                        },
                        "mathematical_or_logical_goal": "Xác định nghĩa mục tiêu",
                        "intermediate_output": "Nghĩa: Màu đỏ",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Nhớ Từ Vựng",
                        "action_verb": "Nhớ",
                        "atomic_instruction": "Nhớ lại từ tiếng Anh chỉ màu đỏ.",
                        "text": "Nhớ lại từ tiếng Anh chỉ màu đỏ.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Màu đỏ trong tiếng Anh là gì?",
                                "options": [
                                        "red",
                                        "blue",
                                        "yellow",
                                        "green"
                                ]
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "Bắt đầu bằng chữ r... red!"
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "red",
                                "feedback_on_error": "Màu đỏ tiếng Anh là 'red' con nhé!"
                        },
                        "mathematical_or_logical_goal": "Truy xuất trí nhớ từ vựng L1 -> L2",
                        "intermediate_output": "red",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Chọn Đáp Án C",
                        "action_verb": "Chọn",
                        "atomic_instruction": "Chọn chữ red điền vào chỗ trống.",
                        "text": "Chọn chữ red điền vào chỗ trống.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Chọn phương án C. red hoàn chỉnh câu:",
                                "options": [
                                        "A. blue",
                                        "B. green",
                                        "C. red",
                                        "D. yellow"
                                ]
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 40
                        },
                        "hints": [
                                "Phương án C là red."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "C. red",
                                "feedback_on_error": "Chọn C. red là đúng rồi!"
                        },
                        "mathematical_or_logical_goal": "Chọn đáp án tương ứng",
                        "intermediate_output": "Phương án C",
                        "is_final_step": true
                }
        ]
},

      // #06. Toán (Grade 2): Bài toán Đội Hai trồng cây (Nhiều hơn một số đơn vị)
      'G2_MATH_06':   "id": "G2_MATH_06",
        "grade": 2,
        "subject": "Toán",
        "cat": "math",
        "catName": "Toán GDPT 2018",
        "icon": "🌳",
        "title": "Bài toán Đội Hai trồng cây (Nhiều hơn một số đơn vị)",
        "island": "study",
        "reward": 130,
        "stepSeconds": 80,
        "original_text": "Đội Một trồng được 35 cây xanh. Đội Hai trồng được nhiều hơn Đội Một 18 cây xanh. Hỏi Đội Hai trồng được bao nhiêu cây xanh?",
        "final_answer": {
                "value": 53,
                "unit": "cây xanh",
                "normalized_display": "53 cây xanh",
                "acceptable_variants": [
                        "53",
                        "53 cây",
                        "53 cây xanh"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Quên phần 'nhớ 1' sang hàng chục dẫn đến kết quả sai phổ biến là 43.",
                "executive_function_scaffolding": "Chia phép cộng thành 2 thao tác: tính hàng đơn vị riêng và cộng hàng chục có nhớ riêng.",
                "visual_or_concrete_aid": "Hộp ghi nhớ số 1 nhỏ đặt trên đỉnh cột hàng chục."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Tách Dữ Kiện",
                        "action_verb": "Tìm",
                        "atomic_instruction": "Tìm số cây Đội Một và phần Đội Hai hơn.",
                        "text": "Tìm số cây Đội Một và phần Đội Hai hơn.",
                        "type": "highlight",
                        "ui_type": "highlight",
                        "ui_data": {
                                "prompt_text": "Tìm 35 cây của Đội Một và 18 cây nhiều hơn:",
                                "highlight_target_segments": [
                                        "35 cây xanh",
                                        "18 cây xanh"
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Đội Một có 35 cây, Đội Hai hơn 18 cây."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": [
                                        "35 cây xanh",
                                        "18 cây xanh"
                                ],
                                "feedback_on_error": "Cùng tìm 2 số 35 và 18 nha!"
                        },
                        "mathematical_or_logical_goal": "Tóm tắt dữ kiện đề bài",
                        "intermediate_output": "Đội Một: 35 cây; Đội Hai nhiều hơn: 18 cây",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Chọn Phép Tính",
                        "action_verb": "Chọn",
                        "atomic_instruction": "Chọn phép cộng 35 cộng 18 để tìm số lớn.",
                        "text": "Chọn phép cộng 35 cộng 18 để tìm số lớn.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Đội Hai nhiều hơn, ta chọn phép tính:",
                                "options": [
                                        "35 + 18",
                                        "35 - 18"
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Nhiều hơn thì chúng mình cộng thêm vào."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "35 + 18",
                                "feedback_on_error": "Nhiều hơn thì ta lấy 35 + 18 nhé!"
                        },
                        "mathematical_or_logical_goal": "Mô hình hóa toán học sơ đồ đoạn thẳng",
                        "intermediate_output": "35 + 18",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Cộng Có Nhớ",
                        "action_verb": "Tính",
                        "atomic_instruction": "Tính 5 cộng 8 bằng 13 nhớ 1.",
                        "text": "Tính 5 cộng 8 bằng 13 nhớ 1.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "35 + 18 = ?",
                                "placeholder": "Nhập kết quả..."
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "milo_thumbs_up",
                                "audio_cue": "gentle_pop_success",
                                "dopamine_points": 35
                        },
                        "hints": [
                                "5 + 8 = 13 viết 3 nhớ 1; 3 + 1 = 4 thêm 1 là 5."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "53",
                                "feedback_on_error": "5 + 8 = 13 nhớ 1, kết quả là 53 nha!"
                        },
                        "mathematical_or_logical_goal": "Thực hiện phép cộng có nhớ trong phạm vi 100",
                        "intermediate_output": "53",
                        "is_final_step": false
                },
                {
                        "step_id": 4,
                        "badge": "Viết Đáp Số",
                        "action_verb": "Kết_luận",
                        "atomic_instruction": "Ghi đáp số 53 cây xanh của Đội Hai.",
                        "text": "Ghi đáp số 53 cây xanh của Đội Hai.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Đáp số cuối cùng của bài toán là:",
                                "options": [
                                        "53 cây xanh",
                                        "43 cây xanh",
                                        "53 cây cam"
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 45
                        },
                        "hints": [
                                "Đội Hai trồng được 53 cây xanh."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "53 cây xanh",
                                "feedback_on_error": "Đáp số là 53 cây xanh con nhé!"
                        },
                        "mathematical_or_logical_goal": "Kết luận lời giải",
                        "intermediate_output": "53 cây xanh",
                        "is_final_step": true
                }
        ]
},

      // #07. Toán (Grade 2): Tính lít dầu còn lại trong can (Bảng nhân 5 & Trừ)
      'G2_MATH_07':   "id": "G2_MATH_07",
        "grade": 2,
        "subject": "Toán",
        "cat": "math",
        "catName": "Toán GDPT 2018",
        "icon": "🛢️",
        "title": "Tính lít dầu còn lại trong can (Bảng nhân 5 & Trừ)",
        "island": "study",
        "reward": 130,
        "stepSeconds": 80,
        "original_text": "Có 5 can đựng dầu, mỗi can chứa 4 lít dầu. Người ta đã lấy ra 7 lít dầu để dùng. Hỏi trong 5 can đó còn lại tất cả bao nhiêu lít dầu?",
        "final_answer": {
                "value": 13,
                "unit": "lít",
                "normalized_display": "13 lít dầu",
                "acceptable_variants": [
                        "13",
                        "13 lít",
                        "13 l",
                        "13 lít dầu"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Trẻ thường dừng lại ngay sau bước 1 (4 x 5 = 20) do thỏa mãn với một phép tính và quên bước trừ 7.",
                "executive_function_scaffolding": "Checklist 2 hộp kiểm: [ ] Tính tổng dầu [ ] Trừ phần đã dùng.",
                "visual_or_concrete_aid": "Vẽ 5 can dầu minh họa, sau đó hiển thị mũi tên rút bớt 7 lít ra ngoài."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Tính Tổng Lít Dầu",
                        "action_verb": "Nhân",
                        "atomic_instruction": "Tính 4 lít nhân 5 can bằng bao nhiêu.",
                        "text": "Tính 4 lít nhân 5 can bằng bao nhiêu.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "4 x 5 = ? (lít)",
                                "placeholder": "Nhập tổng số lít ban đầu..."
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "Bảng nhân 5: 4 x 5 = 20."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "20",
                                "feedback_on_error": "4 nhân 5 bằng 20 lít dầu con nha!"
                        },
                        "mathematical_or_logical_goal": "Tìm đại lượng trung gian tổng thể",
                        "intermediate_output": "4 x 5 = 20 (lít)",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Trừ Số Lít Đã Dùng",
                        "action_verb": "Trừ",
                        "atomic_instruction": "Lấy 20 lít trừ đi 7 lít đã lấy.",
                        "text": "Lấy 20 lít trừ đi 7 lít đã lấy.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "20 - 7 = ? (lít)",
                                "placeholder": "Nhập số lít còn lại..."
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "Lấy 20 trừ đi 7 bằng 13."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "13",
                                "feedback_on_error": "20 trừ 7 bằng 13 lít dầu con nhé!"
                        },
                        "mathematical_or_logical_goal": "Tính số lượng còn lại qua phép trừ",
                        "intermediate_output": "20 - 7 = 13 (lít)",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Ghi Đáp Số",
                        "action_verb": "Kết_luận",
                        "atomic_instruction": "Ghi đáp số 13 lít dầu còn lại.",
                        "text": "Ghi đáp số 13 lít dầu còn lại.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Số lít dầu còn lại trong các can là:",
                                "options": [
                                        "13 lít dầu",
                                        "20 lít dầu",
                                        "7 lít dầu"
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 40
                        },
                        "hints": [
                                "Đáp số là 13 lít dầu."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "13 lít dầu",
                                "feedback_on_error": "Đáp số là 13 lít dầu!"
                        },
                        "mathematical_or_logical_goal": "Kết luận cuối cùng",
                        "intermediate_output": "13 lít dầu",
                        "is_final_step": true
                }
        ]
},

      // #08. Tiếng Việt (Grade 2): Đọc hiểu: Nhận diện mẫu câu Ai làm gì? (Nam giúp bà)
      'G2_VIET_08':   "id": "G2_VIET_08",
        "grade": 2,
        "subject": "Tiếng Việt",
        "cat": "viet",
        "catName": "Tiếng Việt GDPT",
        "icon": "🥬",
        "title": "Đọc hiểu: Nhận diện mẫu câu Ai làm gì? (Nam giúp bà)",
        "island": "study",
        "reward": 120,
        "stepSeconds": 70,
        "original_text": "Đọc đoạn văn sau:\n'Mỗi buổi chiều sau giờ học, Nam thường giúp bà tưới những luống rau xanh mướt sau vườn. Chú cún Mực lon ton chạy quanh đôi chân Nam như muốn cùng tham gia.'\nCâu hỏi: Sau giờ học mỗi buổi chiều, Nam thường làm việc gì để giúp bà?",
        "final_answer": {
                "value": "tưới những luống rau sau vườn",
                "unit": null,
                "normalized_display": "tưới những luống rau sau vườn",
                "acceptable_variants": [
                        "tưới rau",
                        "tưới những luống rau sau vườn",
                        "tưới rau sau vườn",
                        "tưới những luống rau",
                        "tưới rau giúp bà"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Trẻ bị phân tâm bởi câu thứ hai tả 'chú cún Mực lon ton' nên ghi nhầm hành động chơi với cún.",
                "executive_function_scaffolding": "Lọc theo từ khóa mục tiêu: 'Nam' + 'giúp bà'.",
                "visual_or_concrete_aid": "Gạch chân hành động của Nam bằng nét đơn xanh, gạch chân chú cún bằng nét đứt xám."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Xác Định Chủ Thể",
                        "action_verb": "Tìm",
                        "atomic_instruction": "Tìm đối tượng Nam thực hiện việc sau giờ học.",
                        "text": "Tìm đối tượng Nam thực hiện việc sau giờ học.",
                        "type": "highlight",
                        "ui_type": "highlight",
                        "ui_data": {
                                "prompt_text": "Tìm tên bạn nhỏ trong câu đầu tiên:",
                                "highlight_target_segments": [
                                        "Nam"
                                ]
                        },
                        "duration_sec": 70,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Bạn nhỏ giúp bà tên là Nam."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": [
                                        "Nam"
                                ],
                                "feedback_on_error": "Bạn nhỏ tên là Nam nhé!"
                        },
                        "mathematical_or_logical_goal": "Neo định ngữ cảnh câu hỏi",
                        "intermediate_output": "Thời gian: chiều sau giờ học; Người: Nam",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Tìm Cụm Hành Động",
                        "action_verb": "Gạch_chân",
                        "atomic_instruction": "Gạch chân việc Nam tưới những luống rau.",
                        "text": "Gạch chân việc Nam tưới những luống rau.",
                        "type": "highlight",
                        "ui_type": "highlight",
                        "ui_data": {
                                "prompt_text": "Nam làm việc gì giúp bà sau giờ học?",
                                "highlight_target_segments": [
                                        "tưới những luống rau xanh mướt sau vườn"
                                ]
                        },
                        "duration_sec": 70,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "Hành động là tưới những luống rau sau vườn."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": [
                                        "tưới những luống rau xanh mướt sau vườn"
                                ],
                                "feedback_on_error": "Hành động là tưới những luống rau xanh mướt sau vườn!"
                        },
                        "mathematical_or_logical_goal": "Trích xuất cụm vị ngữ chỉ hoạt động",
                        "intermediate_output": "'tưới những luống rau xanh mướt sau vườn'",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Chọn Câu Trả Lời",
                        "action_verb": "Chọn",
                        "atomic_instruction": "Chọn hành động tưới những luống rau sau vườn.",
                        "text": "Chọn hành động tưới những luống rau sau vườn.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Mẫu câu Ai làm gì trong bài diễn tả việc gì?",
                                "options": [
                                        "tưới những luống rau sau vườn",
                                        "chơi cùng cún Mực",
                                        "đi xem phim"
                                ]
                        },
                        "duration_sec": 70,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 45
                        },
                        "hints": [
                                "Chọn đáp án tưới rau giúp bà."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "tưới những luống rau sau vườn",
                                "feedback_on_error": "Nam tưới những luống rau sau vườn nha!"
                        },
                        "mathematical_or_logical_goal": "Khái quát câu trả lời",
                        "intermediate_output": "tưới những luống rau sau vườn",
                        "is_final_step": true
                }
        ]
},

      // #09. Toán (Grade 2): Đổi đơn vị mét sang đề-xi-mét (Đoạn dây của An)
      'G2_MCQ_09':   "id": "G2_MCQ_09",
        "grade": 2,
        "subject": "Toán",
        "cat": "math",
        "catName": "Toán GDPT 2018",
        "icon": "📏",
        "title": "Đổi đơn vị mét sang đề-xi-mét (Đoạn dây của An)",
        "island": "study",
        "reward": 120,
        "stepSeconds": 70,
        "original_text": "Một sợi dây dài 1 m. Bạn An cắt lấy một đoạn dài 4 dm để buộc bưu phẩm. Hỏi đoạn dây còn lại dài bao nhiêu đề-xi-mét?\nA. 5 dm\nB. 6 dm\nC. 7 dm\nD. 96 dm",
        "final_answer": {
                "value": "B",
                "unit": null,
                "normalized_display": "B. 6 dm",
                "acceptable_variants": [
                        "B",
                        "B.",
                        "6 dm",
                        "6",
                        "B. 6 dm"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Bỏ qua bước đổi đơn vị và cố gắng tính 1 - 4 hoặc 1 + 4.",
                "executive_function_scaffolding": "Quy tắc vàng: 'Trước khi cộng trừ, hãy nhìn xem đơn vị có giống nhau không?'.",
                "visual_or_concrete_aid": "Thước đo 1 mét chia thành 10 vạch đề-xi-mét rõ ràng."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Đổi Đơn Vị Đo",
                        "action_verb": "Đổi",
                        "atomic_instruction": "Đổi 1 mét thành bao nhiêu đề-xi-mét.",
                        "text": "Đổi 1 mét thành bao nhiêu đề-xi-mét.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "1 m = ? dm",
                                "options": [
                                        "1 m = 10 dm",
                                        "1 m = 100 dm",
                                        "1 m = 5 dm"
                                ]
                        },
                        "duration_sec": 70,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "1 mét bằng 10 đề-xi-mét con nhé."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "1 m = 10 dm",
                                "feedback_on_error": "1 m bằng 10 dm con nha!"
                        },
                        "mathematical_or_logical_goal": "Đồng nhất đơn vị đo lường",
                        "intermediate_output": "1 m = 10 dm",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Thực Hiện Phép Trừ",
                        "action_verb": "Trừ",
                        "atomic_instruction": "Lấy 10 dm trừ 4 dm đã cắt.",
                        "text": "Lấy 10 dm trừ 4 dm đã cắt.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "10 - 4 = ? (dm)",
                                "placeholder": "Nhập kết quả..."
                        },
                        "duration_sec": 70,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "10 trừ đi 4 còn 6."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "6",
                                "feedback_on_error": "10 trừ 4 bằng 6 dm!"
                        },
                        "mathematical_or_logical_goal": "Thực hiện phép trừ",
                        "intermediate_output": "10 - 4 = 6 dm",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Chọn Phương Án B",
                        "action_verb": "Chọn",
                        "atomic_instruction": "Chọn phương án B có kết quả 6 dm.",
                        "text": "Chọn phương án B có kết quả 6 dm.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Chọn phương án trắc nghiệm đúng:",
                                "options": [
                                        "A. 5 dm",
                                        "B. 6 dm",
                                        "C. 7 dm",
                                        "D. 96 dm"
                                ]
                        },
                        "duration_sec": 70,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 45
                        },
                        "hints": [
                                "Chọn B. 6 dm nhé con."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "B. 6 dm",
                                "feedback_on_error": "Phương án B. 6 dm là chuẩn xác!"
                        },
                        "mathematical_or_logical_goal": "Chọn phương án đúng",
                        "intermediate_output": "Phương án B",
                        "is_final_step": true
                }
        ]
},

      // #10. Tiếng Anh (Grade 2): English Grammar: There is / There are with Plural Nouns
      'G2_ENG_10':   "id": "G2_ENG_10",
        "grade": 2,
        "subject": "Tiếng Anh",
        "cat": "eng",
        "catName": "Tiếng Anh Tiểu Học",
        "icon": "📚",
        "title": "English Grammar: There is / There are with Plural Nouns",
        "island": "study",
        "reward": 120,
        "stepSeconds": 70,
        "original_text": "Choose the correct option:\n'How many books are there on the table?' - 'There ______ three books.'\nA. is\nB. are\nC. am\nD. be",
        "final_answer": {
                "value": "B",
                "unit": null,
                "normalized_display": "B. are",
                "acceptable_variants": [
                        "B",
                        "B.",
                        "are",
                        "B. are"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Phản xạ điền 'is' theo thói quen cửa miệng do chưa kịp phân tích cụm từ số nhiều.",
                "executive_function_scaffolding": "Khoanh tròn số '3' và đuôi '-s' trong 'books' trước khi chọn từ.",
                "visual_or_concrete_aid": "Ký hiệu quả cân so sánh: 1 vật = IS; 2+ vật = ARE."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Nhìn Danh Từ",
                        "action_verb": "Đọc",
                        "atomic_instruction": "Đọc cụm three books và nhận biết số nhiều.",
                        "text": "Đọc cụm three books và nhận biết số nhiều.",
                        "type": "checkbox",
                        "ui_type": "checkbox",
                        "ui_data": {
                                "prompt_text": "'three books' có 3 quyển sách (số nhiều), đúng không con?",
                                "options": [
                                        "Đúng là số nhiều"
                                ]
                        },
                        "duration_sec": 70,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "3 quyển sách là từ 2 vật trở lên, là số nhiều."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": true,
                                "feedback_on_error": "3 quyển sách là danh từ số nhiều nha!"
                        },
                        "mathematical_or_logical_goal": "Xác định số lượng của danh từ bổ ngữ",
                        "intermediate_output": "'three books' là số nhiều (plural)",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Áp Dụng Quy Tắc",
                        "action_verb": "Nhớ",
                        "atomic_instruction": "Nhớ quy tắc dùng There are cho số nhiều.",
                        "text": "Nhớ quy tắc dùng There are cho số nhiều.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Số nhiều (từ 2 vật) chúng mình dùng từ nào?",
                                "options": [
                                        "There are",
                                        "There is"
                                ]
                        },
                        "duration_sec": 70,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "Số nhiều dùng are, số ít dùng is."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "There are",
                                "feedback_on_error": "Số nhiều chúng mình dùng There are nhé!"
                        },
                        "mathematical_or_logical_goal": "Quy tắc ngữ pháp thì hiện tại",
                        "intermediate_output": "Chọn động từ to be: are",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Chọn Phương Án B",
                        "action_verb": "Chọn",
                        "atomic_instruction": "Chọn phương án B chứa từ are.",
                        "text": "Chọn phương án B chứa từ are.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Chọn phương án điền vào chỗ trống:",
                                "options": [
                                        "A. is",
                                        "B. are",
                                        "C. am",
                                        "D. be"
                                ]
                        },
                        "duration_sec": 70,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 45
                        },
                        "hints": [
                                "Chọn phương án B. are."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "B. are",
                                "feedback_on_error": "Phương án B. are là chính xác!"
                        },
                        "mathematical_or_logical_goal": "Chọn đáp án",
                        "intermediate_output": "Phương án B",
                        "is_final_step": true
                }
        ]
},

      // #11. Toán (Grade 3): Cửa hàng bán gạo (Gấp một số lên nhiều lần & Tổng)
      'G3_MATH_11':   "id": "G3_MATH_11",
        "grade": 3,
        "subject": "Toán",
        "cat": "math",
        "catName": "Toán GDPT 2018",
        "icon": "🍚",
        "title": "Cửa hàng bán gạo (Gấp một số lên nhiều lần & Tổng)",
        "island": "study",
        "reward": 140,
        "stepSeconds": 90,
        "original_text": "Cửa hàng buổi sáng bán được 24 kg gạo. Buổi chiều bán được gấp 3 lần buổi sáng. Hỏi cả hai buổi cửa hàng bán được tất cả bao nhiêu ki-lô-gam gạo?",
        "final_answer": {
                "value": 96,
                "unit": "kg",
                "normalized_display": "96 kg gạo",
                "acceptable_variants": [
                        "96",
                        "96 kg",
                        "96 ki-lô-gam",
                        "96 kg gạo"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Tưởng rằng tìm ra 72 kg là đã hoàn thành bài toán và dừng lại mà không tính tổng cả hai buổi.",
                "executive_function_scaffolding": "Nhắc nhở câu hỏi cốt lõi: 'Đề bài hỏi buổi chiều hay hỏi CẢ HAI BUỔI?'.",
                "visual_or_concrete_aid": "Sơ đồ đoạn thẳng: Sáng 1 đoạn; Chiều 3 đoạn; ngoặc nhọn hỏi chấm tổng cả 4 đoạn."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Tìm Gạo Buổi Chiều",
                        "action_verb": "Nhân",
                        "atomic_instruction": "Nhân 24 kg với 3 để tìm gạo chiều.",
                        "text": "Nhân 24 kg với 3 để tìm gạo chiều.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "24 x 3 = ? (kg)",
                                "placeholder": "Nhập số gạo buổi chiều..."
                        },
                        "duration_sec": 90,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "4 x 3 = 12 viết 2 nhớ 1; 2 x 3 = 6 thêm 1 là 7."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "72",
                                "feedback_on_error": "24 nhân 3 bằng 72 kg gạo con nhé!"
                        },
                        "mathematical_or_logical_goal": "Tính đại lượng gấp lên nhiều lần",
                        "intermediate_output": "24 x 3 = 72 (kg)",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Tính Tổng Hai Buổi",
                        "action_verb": "Cộng",
                        "atomic_instruction": "Cộng 24 kg sáng với 72 kg chiều.",
                        "text": "Cộng 24 kg sáng với 72 kg chiều.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "24 + 72 = ? (kg)",
                                "placeholder": "Nhập tổng số gạo cả ngày..."
                        },
                        "duration_sec": 90,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 35
                        },
                        "hints": [
                                "4 + 2 = 6, 2 + 7 = 9. Kết quả là 96."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "96",
                                "feedback_on_error": "24 cộng 72 bằng 96 kg gạo nha!"
                        },
                        "mathematical_or_logical_goal": "Tính tổng hai đại lượng",
                        "intermediate_output": "24 + 72 = 96 (kg)",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Ghi Đáp Số",
                        "action_verb": "Kết_luận",
                        "atomic_instruction": "Ghi đáp số hoàn chỉnh 96 kg gạo.",
                        "text": "Ghi đáp số hoàn chỉnh 96 kg gạo.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Chọn đáp số đúng cho cả hai buổi:",
                                "options": [
                                        "96 kg gạo",
                                        "72 kg gạo",
                                        "48 kg gạo"
                                ]
                        },
                        "duration_sec": 90,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 45
                        },
                        "hints": [
                                "Đáp số cả hai buổi là 96 kg gạo."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "96 kg gạo",
                                "feedback_on_error": "Đáp số là 96 kg gạo!"
                        },
                        "mathematical_or_logical_goal": "Kết luận bài toán",
                        "intermediate_output": "96 kg gạo",
                        "is_final_step": true
                }
        ]
},

      // #12. Toán (Grade 3): Bài toán rút về đơn vị: Thưởng vở học sinh giỏi
      'G3_MATH_12':   "id": "G3_MATH_12",
        "grade": 3,
        "subject": "Toán",
        "cat": "math",
        "catName": "Toán GDPT 2018",
        "icon": "📓",
        "title": "Bài toán rút về đơn vị: Thưởng vở học sinh giỏi",
        "island": "study",
        "reward": 140,
        "stepSeconds": 90,
        "original_text": "Cô giáo có 35 quyển vở thưởng đều cho 7 bạn học sinh giỏi. Hỏi nếu cô muốn thưởng cho 5 bạn học sinh giỏi như thế thì cần bao nhiêu quyển vở?",
        "final_answer": {
                "value": 25,
                "unit": "quyển vở",
                "normalized_display": "25 quyển vở",
                "acceptable_variants": [
                        "25",
                        "25 quyển",
                        "25 quyển vở"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Trẻ bối rối trước sự xuất hiện của hai số 5 (5 quyển và 5 bạn) dẫn đến nhầm lẫn khái niệm.",
                "executive_function_scaffolding": "Phân định rõ danh từ đi kèm: '5 quyển/bạn' vs '5 bạn học sinh'.",
                "visual_or_concrete_aid": "Minh họa 1 gói quà nhỏ đại diện cho 1 bạn chứa 5 cuốn vở."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Rút Về Một Bạn",
                        "action_verb": "Chia",
                        "atomic_instruction": "Chia 35 quyển cho 7 bạn bằng mấy quyển.",
                        "text": "Chia 35 quyển cho 7 bạn bằng mấy quyển.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "35 : 7 = ? (quyển vở mỗi bạn)",
                                "placeholder": "Nhập số vở một bạn nhận..."
                        },
                        "duration_sec": 90,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "Bảng chia 7: 7 x 5 = 35."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "5",
                                "feedback_on_error": "Mỗi bạn nhận được 5 quyển vở con nhé!"
                        },
                        "mathematical_or_logical_goal": "Bước rút về giá trị 1 đơn vị",
                        "intermediate_output": "35 : 7 = 5 (quyển vở)",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Tính Cho 5 Bạn",
                        "action_verb": "Nhân",
                        "atomic_instruction": "Nhân 5 quyển một bạn với 5 bạn.",
                        "text": "Nhân 5 quyển một bạn với 5 bạn.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "5 x 5 = ? (quyển vở)",
                                "placeholder": "Nhập số vở cho 5 bạn..."
                        },
                        "duration_sec": 90,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 35
                        },
                        "hints": [
                                "Bảng nhân 5: 5 x 5 = 25."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "25",
                                "feedback_on_error": "5 bạn nhận 25 quyển vở nha!"
                        },
                        "mathematical_or_logical_goal": "Tính giá trị nhiều đơn vị cùng loại",
                        "intermediate_output": "5 x 5 = 25 (quyển vở)",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Ghi Đáp Số",
                        "action_verb": "Kết_luận",
                        "atomic_instruction": "Ghi đáp số 25 quyển vở cô giáo thưởng.",
                        "text": "Ghi đáp số 25 quyển vở cô giáo thưởng.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Đáp số của bài toán là:",
                                "options": [
                                        "25 quyển vở",
                                        "35 quyển vở",
                                        "15 quyển vở"
                                ]
                        },
                        "duration_sec": 90,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 45
                        },
                        "hints": [
                                "Đáp số là 25 quyển vở."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "25 quyển vở",
                                "feedback_on_error": "Đáp số là 25 quyển vở!"
                        },
                        "mathematical_or_logical_goal": "Đáp số hoàn thiện",
                        "intermediate_output": "25 quyển vở",
                        "is_final_step": true
                }
        ]
},

      // #13. Tiếng Việt (Grade 3): Đọc hiểu: Biện pháp so sánh Mặt hồ Ba Bể
      'G3_VIET_13':   "id": "G3_VIET_13",
        "grade": 3,
        "subject": "Tiếng Việt",
        "cat": "viet",
        "catName": "Tiếng Việt GDPT",
        "icon": "🪞",
        "title": "Đọc hiểu: Biện pháp so sánh Mặt hồ Ba Bể",
        "island": "study",
        "reward": 130,
        "stepSeconds": 80,
        "original_text": "Đọc đoạn văn sau:\n'Mặt hồ Ba Bể phẳng lặng và trong veo như một tấm gương khổng lồ soi bóng núi rừng hùng vĩ. Những chiếc thuyền độc mộc lướt nhẹ trên mặt nước mang lại cảm giác thanh bình, êm ả.'\nCâu hỏi: Trong đoạn văn trên, mặt hồ Ba Bể được so sánh với sự vật nào?",
        "final_answer": {
                "value": "một tấm gương khổng lồ",
                "unit": null,
                "normalized_display": "một tấm gương khổng lồ",
                "acceptable_variants": [
                        "tấm gương khổng lồ",
                        "một tấm gương khổng lồ",
                        "tấm gương",
                        "gương khổng lồ"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Sao nhãng vào vế vị ngữ phía sau 'soi bóng núi rừng hùng vĩ' và trả lời nhầm là 'núi rừng'.",
                "executive_function_scaffolding": "Dùng công thức khuôn mẫu: [Sự vật A] + NHƯ + [Sự vật B].",
                "visual_or_concrete_aid": "Khung bảng 2 cột đối chiếu: Vế A | Từ nối | Vế B."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Tìm Từ So Sánh",
                        "action_verb": "Tìm",
                        "atomic_instruction": "Tìm từ như dùng để nối câu so sánh.",
                        "text": "Tìm từ như dùng để nối câu so sánh.",
                        "type": "highlight",
                        "ui_type": "highlight",
                        "ui_data": {
                                "prompt_text": "Tìm từ chỉ quan hệ so sánh trong câu 1:",
                                "highlight_target_segments": [
                                        "như"
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Từ so sánh phổ biến nhất là từ 'như'."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": [
                                        "như"
                                ],
                                "feedback_on_error": "Từ so sánh là từ 'như' nhé!"
                        },
                        "mathematical_or_logical_goal": "Nhận diện dấu hiệu tu từ so sánh",
                        "intermediate_output": "Từ so sánh: 'như'",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Tìm Hình Ảnh So Sánh",
                        "action_verb": "Xác_định",
                        "atomic_instruction": "Xác định cụm từ đứng sau từ như.",
                        "text": "Xác định cụm từ đứng sau từ như.",
                        "type": "highlight",
                        "ui_type": "highlight",
                        "ui_data": {
                                "prompt_text": "Mặt hồ phẳng lặng và trong veo như cái gì?",
                                "highlight_target_segments": [
                                        "một tấm gương khổng lồ"
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 35
                        },
                        "hints": [
                                "Đứng sau từ 'như' là 'một tấm gương khổng lồ'."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": [
                                        "một tấm gương khổng lồ"
                                ],
                                "feedback_on_error": "Hình ảnh so sánh là 'một tấm gương khổng lồ'!"
                        },
                        "mathematical_or_logical_goal": "Bóc tách cấu trúc A như B",
                        "intermediate_output": "Vế A: Mặt hồ Ba Bể; Vế B: một tấm gương khổng lồ",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Chọn Tấm Gương Khổng Lồ",
                        "action_verb": "Chọn",
                        "atomic_instruction": "Chọn đáp án một tấm gương khổng lồ.",
                        "text": "Chọn đáp án một tấm gương khổng lồ.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Sự vật được dùng để so sánh với mặt hồ là:",
                                "options": [
                                        "một tấm gương khổng lồ",
                                        "núi rừng Ba Bể",
                                        "chiếc thuyền nan"
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 45
                        },
                        "hints": [
                                "Chọn 'một tấm gương khổng lồ'."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "một tấm gương khổng lồ",
                                "feedback_on_error": "Đáp án là một tấm gương khổng lồ!"
                        },
                        "mathematical_or_logical_goal": "Đưa ra đáp án chuẩn xác",
                        "intermediate_output": "một tấm gương khổng lồ",
                        "is_final_step": true
                }
        ]
},

      // #14. Toán (Grade 3): Tính chu vi mảnh đất hình chữ nhật (15m và 8m)
      'G3_MCQ_14':   "id": "G3_MCQ_14",
        "grade": 3,
        "subject": "Toán",
        "cat": "math",
        "catName": "Toán GDPT 2018",
        "icon": "📐",
        "title": "Tính chu vi mảnh đất hình chữ nhật (15m và 8m)",
        "island": "study",
        "reward": 130,
        "stepSeconds": 80,
        "original_text": "Một mảnh đất hình chữ nhật có chiều dài 15 m và chiều rộng 8 m. Chu vi của mảnh đất đó là:\nA. 23 m\nB. 46 m\nC. 120 m\nD. 46 mét vuông",
        "final_answer": {
                "value": "B",
                "unit": null,
                "normalized_display": "B. 46 m",
                "acceptable_variants": [
                        "B",
                        "B.",
                        "46 m",
                        "46",
                        "B. 46 m"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Nhìn thấy số 46 vội vàng chọn ngay đáp án D mà không đọc đơn vị mét vuông ở đuôi.",
                "executive_function_scaffolding": "Buộc học sinh kiểm tra hai bước: (1) Số có đúng không? (2) Đơn vị có đúng không?",
                "visual_or_concrete_aid": "Vẽ hình chữ nhật với 4 cạnh đánh dấu độ dài quanh viền."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Nhớ Công Thức Chu Vi",
                        "action_verb": "Nhớ",
                        "atomic_instruction": "Nhớ công thức: dài cộng rộng nhân hai.",
                        "text": "Nhớ công thức: dài cộng rộng nhân hai.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Công thức tính chu vi hình chữ nhật là:",
                                "options": [
                                        "(Dài + Rộng) x 2",
                                        "Dài x Rộng",
                                        "Dài + Rộng"
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Chu vi bằng (dài + rộng) x 2."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "(Dài + Rộng) x 2",
                                "feedback_on_error": "Chu vi hình chữ nhật bằng (Dài + Rộng) x 2 nhé!"
                        },
                        "mathematical_or_logical_goal": "Truy xuất công thức hình học",
                        "intermediate_output": "P = (a + b) x 2",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Tính Chu Vi",
                        "action_verb": "Tính",
                        "atomic_instruction": "Tính 15 cộng 8 rồi nhân 2.",
                        "text": "Tính 15 cộng 8 rồi nhân 2.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "(15 + 8) x 2 = ? (m)",
                                "placeholder": "Nhập chu vi..."
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 35
                        },
                        "hints": [
                                "15 + 8 = 23; 23 x 2 = 46."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "46",
                                "feedback_on_error": "23 nhân 2 bằng 46 m con nha!"
                        },
                        "mathematical_or_logical_goal": "Thực hiện tính toán 2 bước",
                        "intermediate_output": "46 m",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Chọn Phương Án B",
                        "action_verb": "Chọn",
                        "atomic_instruction": "Chọn phương án B có đơn vị mét (46 m).",
                        "text": "Chọn phương án B có đơn vị mét (46 m).",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Chú ý đơn vị mét (m), không phải mét vuông (m2):",
                                "options": [
                                        "A. 23 m",
                                        "B. 46 m",
                                        "C. 120 m",
                                        "D. 46 mét vuông"
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 45
                        },
                        "hints": [
                                "Chu vi đơn vị là m: B. 46 m."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "B. 46 m",
                                "feedback_on_error": "Đáp án đúng là B. 46 m!"
                        },
                        "mathematical_or_logical_goal": "Kiểm tra danh số & loại trừ bẫy",
                        "intermediate_output": "Chọn phương án B",
                        "is_final_step": true
                }
        ]
},

      // #15. Tiếng Anh (Grade 3): English Sentence Reordering: Khả năng của chú vịt (can/can't)
      'G3_ENG_15':   "id": "G3_ENG_15",
        "grade": 3,
        "subject": "Tiếng Anh",
        "cat": "eng",
        "catName": "Tiếng Anh Tiểu Học",
        "icon": "🦆",
        "title": "English Sentence Reordering: Khả năng của chú vịt (can/can't)",
        "island": "study",
        "reward": 130,
        "stepSeconds": 80,
        "original_text": "Reorder the words to make a correct sentence:\n'swim / but / can / fly / can't / A duck / .'\nChoose the correct sentence:\nA. A duck can swim but can't fly.\nB. A duck can't swim but can fly.\nC. Can swim but fly a duck can't.\nD. A duck fly can but can't swim.",
        "final_answer": {
                "value": "A",
                "unit": null,
                "normalized_display": "A. A duck can swim but can't fly.",
                "acceptable_variants": [
                        "A",
                        "A.",
                        "A duck can swim but can't fly.",
                        "A duck can swim but can't fly"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Quá tải khi sắp xếp 6 mảnh từ xáo trộn trong đầu cùng một lúc.",
                "executive_function_scaffolding": "Phân nhóm từ: Cụm 1 (Con gì? -> A duck), Cụm 2 (Làm được gì? -> can swim), Cụm 3 (Không làm được gì? -> can't fly).",
                "visual_or_concrete_aid": "Các khối hình ghép puzzle 3 mảnh có khớp nối màu sắc."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Tìm Chủ Ngữ Đầu Câu",
                        "action_verb": "Tìm",
                        "atomic_instruction": "Tìm cụm từ viết hoa A duck làm chủ ngữ.",
                        "text": "Tìm cụm từ viết hoa A duck làm chủ ngữ.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Từ nào viết hoa đứng đầu câu?",
                                "options": [
                                        "A duck",
                                        "can swim",
                                        "fly",
                                        "but"
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Chữ 'A duck' có chữ A viết hoa."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "A duck",
                                "feedback_on_error": "Chủ ngữ đầu câu là A duck con nhé!"
                        },
                        "mathematical_or_logical_goal": "Định vị thành phần chủ ngữ",
                        "intermediate_output": "Chủ ngữ: A duck",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Ghép Cấu Trúc Can / Can't",
                        "action_verb": "Ghép",
                        "atomic_instruction": "Ghép hành động bơi được và không bay được.",
                        "text": "Ghép hành động bơi được và không bay được.",
                        "type": "order_sequencing",
                        "ui_type": "order_sequencing",
                        "ui_data": {
                                "prompt_text": "Sắp xếp thứ tự các vế câu:",
                                "items_to_drag": [
                                        "A duck",
                                        "can swim",
                                        "but",
                                        "can't fly."
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 35
                        },
                        "hints": [
                                "A duck -> can swim -> but -> can't fly."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": [
                                        "A duck",
                                        "can swim",
                                        "but",
                                        "can't fly."
                                ],
                                "feedback_on_error": "Vịt biết bơi nhưng không biết bay: can swim but can't fly."
                        },
                        "mathematical_or_logical_goal": "Mô hình hóa cú pháp câu",
                        "intermediate_output": "can swim but can't fly",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Chọn Câu Hoàn Chỉnh A",
                        "action_verb": "Chọn",
                        "atomic_instruction": "Chọn phương án A ghép câu đúng ngữ pháp.",
                        "text": "Chọn phương án A ghép câu đúng ngữ pháp.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Chọn câu hoàn chỉnh chính xác:",
                                "options": [
                                        "A. A duck can swim but can't fly.",
                                        "B. A duck can't swim but can fly.",
                                        "C. Can swim but fly a duck can't."
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 45
                        },
                        "hints": [
                                "Phương án A là câu chuẩn xác."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "A. A duck can swim but can't fly.",
                                "feedback_on_error": "Phương án A là đáp án chính xác!"
                        },
                        "mathematical_or_logical_goal": "Khẳng định lựa chọn đúng",
                        "intermediate_output": "Phương án A",
                        "is_final_step": true
                }
        ]
},

      // #16. Toán (Grade 4): Toán Tổng - Hiệu: Sách quyên góp hai lớp 4A và 4B
      'G4_MATH_16':   "id": "G4_MATH_16",
        "grade": 4,
        "subject": "Toán",
        "cat": "math",
        "catName": "Toán GDPT 2018",
        "icon": "📚",
        "title": "Toán Tổng - Hiệu: Sách quyên góp hai lớp 4A và 4B",
        "island": "study",
        "reward": 150,
        "stepSeconds": 90,
        "original_text": "Hai lớp 4A và 4B quyên góp được tất cả 280 quyển sách cho thư viện vùng cao. Lớp 4A quyên góp được nhiều hơn lớp 4B là 40 quyển sách. Hỏi mỗi lớp quyên góp được bao nhiêu quyển sách?",
        "final_answer": {
                "value": "Lớp 4A: 160 quyển, Lớp 4B: 120 quyển",
                "unit": "quyển sách",
                "normalized_display": "Lớp 4A: 160 quyển, Lớp 4B: 120 quyển",
                "acceptable_variants": [
                        "Lớp 4A: 160 quyển, Lớp 4B: 120 quyển",
                        "4A: 160 quyển, 4B: 120 quyển",
                        "4A: 160, 4B: 120",
                        "160 quyển và 120 quyển",
                        "160 và 120",
                        "160, 120"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Nhớ lộn công thức lấy Tổng trừ Hiệu nhưng quên chia 2 hoặc chỉ tính một lớp rồi nộp bài.",
                "executive_function_scaffolding": "Lộ trình 3 hộp: [1] Tính 4A qua công thức; [2] Tính 4B qua phép trừ; [3] Soát lại tổng xem có bằng 280 không.",
                "visual_or_concrete_aid": "Vẽ sơ đồ đoạn thẳng: Đoạn 4A dài hơn đoạn 4B một mẩu 40 quyển."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Xác Định Tổng Và Hiệu",
                        "action_verb": "Tách",
                        "atomic_instruction": "Tách tổng 280 quyển và hiệu 40 quyển.",
                        "text": "Tách tổng 280 quyển và hiệu 40 quyển.",
                        "type": "highlight",
                        "ui_type": "highlight",
                        "ui_data": {
                                "prompt_text": "Tìm tổng số sách và số sách lớp 4A nhiều hơn:",
                                "highlight_target_segments": [
                                        "280 quyển sách",
                                        "40 quyển"
                                ]
                        },
                        "duration_sec": 90,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Tổng là 280 quyển, hiệu là 40 quyển."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": [
                                        "280 quyển sách",
                                        "40 quyển"
                                ],
                                "feedback_on_error": "Tổng = 280, Hiệu = 40 nhé!"
                        },
                        "mathematical_or_logical_goal": "Phân loại dạng toán Tổng - Hiệu",
                        "intermediate_output": "Tổng = 280; Hiệu = 40; Số lớn: 4A; Số bé: 4B",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Tìm Sách Lớp 4A",
                        "action_verb": "Tính",
                        "atomic_instruction": "Tính 280 cộng 40 rồi chia cho 2.",
                        "text": "Tính 280 cộng 40 rồi chia cho 2.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "(280 + 40) : 2 = ? (quyển lớp 4A)",
                                "placeholder": "Nhập số sách 4A..."
                        },
                        "duration_sec": 90,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "280 + 40 = 320; 320 : 2 = 160."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "160",
                                "feedback_on_error": "Lớp 4A quyên góp được 160 quyển con nha!"
                        },
                        "mathematical_or_logical_goal": "Tính số lớn",
                        "intermediate_output": "(280 + 40) : 2 = 320 : 2 = 160 (quyển)",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Tìm Sách Lớp 4B",
                        "action_verb": "Trừ",
                        "atomic_instruction": "Lấy 160 trừ đi 40 để ra lớp 4B.",
                        "text": "Lấy 160 trừ đi 40 để ra lớp 4B.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "160 - 40 = ? (quyển lớp 4B)",
                                "placeholder": "Nhập số sách 4B..."
                        },
                        "duration_sec": 90,
                        "immediate_reinforcer": {
                                "visual_asset": "milo_thumbs_up",
                                "audio_cue": "gentle_pop_success",
                                "dopamine_points": 35
                        },
                        "hints": [
                                "160 - 40 = 120 quyển."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "120",
                                "feedback_on_error": "Lớp 4B quyên góp 120 quyển nhé!"
                        },
                        "mathematical_or_logical_goal": "Tính số bé",
                        "intermediate_output": "160 - 40 = 120 (quyển)",
                        "is_final_step": false
                },
                {
                        "step_id": 4,
                        "badge": "Ghi Rõ Hai Lớp",
                        "action_verb": "Kết_luận",
                        "atomic_instruction": "Chọn đáp án ghi rõ kết quả cả hai lớp.",
                        "text": "Chọn đáp án ghi rõ kết quả cả hai lớp.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Đáp số đầy đủ của bài toán là:",
                                "options": [
                                        "Lớp 4A: 160 quyển, Lớp 4B: 120 quyển",
                                        "Lớp 4A: 140 quyển, Lớp 4B: 140 quyển",
                                        "Lớp 4A: 180 quyển, Lớp 4B: 100 quyển"
                                ]
                        },
                        "duration_sec": 90,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 50
                        },
                        "hints": [
                                "4A: 160 quyển, 4B: 120 quyển."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "Lớp 4A: 160 quyển, Lớp 4B: 120 quyển",
                                "feedback_on_error": "Đáp số là 4A: 160 quyển, 4B: 120 quyển!"
                        },
                        "mathematical_or_logical_goal": "Kiểm thử và kết luận",
                        "intermediate_output": "Lớp 4A: 160 quyển; Lớp 4B: 120 quyển",
                        "is_final_step": true
                }
        ]
},

      // #17. Toán (Grade 4): Tìm phân số của một số: Đàn gia cầm gà và vịt
      'G4_MATH_17':   "id": "G4_MATH_17",
        "grade": 4,
        "subject": "Toán",
        "cat": "math",
        "catName": "Toán GDPT 2018",
        "icon": "🐥",
        "title": "Tìm phân số của một số: Đàn gia cầm gà và vịt",
        "island": "study",
        "reward": 140,
        "stepSeconds": 90,
        "original_text": "Một trang trại có 1200 con gia cầm gồm gà và vịt. Trong đó số gà chiếm 3/5 tổng số gia cầm. Hỏi trang trại đó có bao nhiêu con vịt?",
        "final_answer": {
                "value": 480,
                "unit": "con vịt",
                "normalized_display": "480 con vịt",
                "acceptable_variants": [
                        "480",
                        "480 con",
                        "480 con vịt"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Tính xong 720 con gà thì ngỡ đã xong bài và điền 720 làm đáp số, bỏ quên câu hỏi về con vịt.",
                "executive_function_scaffolding": "Highlight câu hỏi mục tiêu: 'Hỏi trang trại có bao nhiêu CON VỊT?'.",
                "visual_or_concrete_aid": "Thanh đồ họa chia 5 phần bằng nhau: 3 phần màu vàng là gà (720), 2 phần màu xanh là vịt (?)."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Tính Số Con Gà",
                        "action_verb": "Tính",
                        "atomic_instruction": "Lấy 1200 chia 5 rồi nhân 3 tìm gà.",
                        "text": "Lấy 1200 chia 5 rồi nhân 3 tìm gà.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "1200 x 3/5 = ? (con gà)",
                                "placeholder": "Nhập số con gà..."
                        },
                        "duration_sec": 90,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "1200 : 5 = 240; 240 x 3 = 720."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "720",
                                "feedback_on_error": "Trang trại có 720 con gà nhé con!"
                        },
                        "mathematical_or_logical_goal": "Tìm giá trị phân số của một số",
                        "intermediate_output": "1200 x 3/5 = 720 (con gà)",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Tìm Số Con Vịt",
                        "action_verb": "Trừ",
                        "atomic_instruction": "Lấy 1200 tổng trừ đi 720 con gà.",
                        "text": "Lấy 1200 tổng trừ đi 720 con gà.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "1200 - 720 = ? (con vịt)",
                                "placeholder": "Nhập số con vịt..."
                        },
                        "duration_sec": 90,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 35
                        },
                        "hints": [
                                "1200 - 720 = 480."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "480",
                                "feedback_on_error": "Số vịt là 480 con con nhé!"
                        },
                        "mathematical_or_logical_goal": "Thực hiện phép trừ bù tập hợp",
                        "intermediate_output": "1200 - 720 = 480 (con vịt)",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Ghi Đáp Số Vịt",
                        "action_verb": "Kết_luận",
                        "atomic_instruction": "Ghi đáp số 480 con vịt của trang trại.",
                        "text": "Ghi đáp số 480 con vịt của trang trại.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Đề bài hỏi số con vịt, vậy đáp số là:",
                                "options": [
                                        "480 con vịt",
                                        "720 con gà",
                                        "600 con vịt"
                                ]
                        },
                        "duration_sec": 90,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 45
                        },
                        "hints": [
                                "Đáp số là 480 con vịt."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "480 con vịt",
                                "feedback_on_error": "Đáp số là 480 con vịt!"
                        },
                        "mathematical_or_logical_goal": "Kết luận",
                        "intermediate_output": "480 con vịt",
                        "is_final_step": true
                }
        ]
},

      // #18. Tiếng Việt (Grade 4): Đọc hiểu: Biện pháp nhân hóa Chị Gió thì thầm
      'G4_VIET_18':   "id": "G4_VIET_18",
        "grade": 4,
        "subject": "Tiếng Việt",
        "cat": "viet",
        "catName": "Tiếng Việt GDPT",
        "icon": "🌾",
        "title": "Đọc hiểu: Biện pháp nhân hóa Chị Gió thì thầm",
        "island": "study",
        "reward": 130,
        "stepSeconds": 80,
        "original_text": "Đọc đoạn văn sau:\n'Chị Gió bay qua những cánh đồng, khẽ thì thầm với các bông lúa non. Những bông lúa bẽn lẽn nghiêng đầu chào đón chị, rộn rã rì rào ca hát dưới nắng sớm.'\nCâu hỏi: Trong đoạn văn trên, chị Gió được gán cho những hành động giống như con người qua các từ ngữ nào?",
        "final_answer": {
                "value": "thì thầm",
                "unit": null,
                "normalized_display": "thì thầm (hoặc khẽ thì thầm)",
                "acceptable_variants": [
                        "thì thầm",
                        "khẽ thì thầm",
                        "khẽ thì thầm với các bông lúa non"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Nhầm lẫn hành động của chị Gió với hành động của bông lúa ('bẽn lẽn nghiêng đầu', 'ca hát').",
                "executive_function_scaffolding": "Tạo bảng phân loại: Cột 1: Hành động của chị Gió | Cột 2: Hành động của bông lúa.",
                "visual_or_concrete_aid": "Tô màu hồng cho chủ ngữ 'chị Gió' và mũi tên chỉ đến từ 'thì thầm'."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Xác Định Chị Gió",
                        "action_verb": "Tìm",
                        "atomic_instruction": "Tìm đối tượng được nhân hóa là chị Gió.",
                        "text": "Tìm đối tượng được nhân hóa là chị Gió.",
                        "type": "highlight",
                        "ui_type": "highlight",
                        "ui_data": {
                                "prompt_text": "Tìm tên sự vật thiên nhiên được gọi như con người:",
                                "highlight_target_segments": [
                                        "Chị Gió"
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Gió được gọi thân mật bằng 'Chị'."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": [
                                        "Chị Gió"
                                ],
                                "feedback_on_error": "Đó là Chị Gió nhé!"
                        },
                        "mathematical_or_logical_goal": "Xác định thực thể trung tâm",
                        "intermediate_output": "Thực thể: chị Gió",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Tìm Hành Động Con Người",
                        "action_verb": "Gạch_chân",
                        "atomic_instruction": "Gạch chân từ thì thầm trong câu thứ nhất.",
                        "text": "Gạch chân từ thì thầm trong câu thứ nhất.",
                        "type": "highlight",
                        "ui_type": "highlight",
                        "ui_data": {
                                "prompt_text": "Chị Gió làm hành động gì của con người với lúa non?",
                                "highlight_target_segments": [
                                        "khẽ thì thầm"
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 35
                        },
                        "hints": [
                                "Hành động nói nhỏ: thì thầm."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": [
                                        "khẽ thì thầm"
                                ],
                                "feedback_on_error": "Chị Gió khẽ thì thầm con nhé!"
                        },
                        "mathematical_or_logical_goal": "Phân tích phép nhân hóa qua hành động",
                        "intermediate_output": "Từ chỉ hành động: 'thì thầm' (hoặc 'khẽ thì thầm')",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Chọn Từ Nhân Hóa",
                        "action_verb": "Chọn",
                        "atomic_instruction": "Chọn từ thì thầm là hành động nhân hóa.",
                        "text": "Chọn từ thì thầm là hành động nhân hóa.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Từ ngữ thể hiện hành động nhân hóa của Chị Gió là:",
                                "options": [
                                        "thì thầm (hoặc khẽ thì thầm)",
                                        "uốn câu",
                                        "nở nụ cười"
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 45
                        },
                        "hints": [
                                "Chọn 'thì thầm'."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "thì thầm (hoặc khẽ thì thầm)",
                                "feedback_on_error": "Đáp án đúng là thì thầm!"
                        },
                        "mathematical_or_logical_goal": "Đưa ra đáp án chuẩn",
                        "intermediate_output": "thì thầm (khẽ thì thầm)",
                        "is_final_step": true
                }
        ]
},

      // #19. Toán (Grade 4): Tính diện tích hình bình hành (Đáy 24m, chiều cao 15m)
      'G4_MCQ_19':   "id": "G4_MCQ_19",
        "grade": 4,
        "subject": "Toán",
        "cat": "math",
        "catName": "Toán GDPT 2018",
        "icon": "🔷",
        "title": "Tính diện tích hình bình hành (Đáy 24m, chiều cao 15m)",
        "island": "study",
        "reward": 140,
        "stepSeconds": 85,
        "original_text": "Một mảnh đất hình bình hành có độ dài đáy là 24 m, chiều cao tương ứng là 15 m và độ dài cạnh bên là 18 m. Diện tích mảnh đất đó là:\nA. 360 m2\nB. 432 m2\nC. 78 m\nD. 180 m2",
        "final_answer": {
                "value": "A",
                "unit": null,
                "normalized_display": "A. 360 m2",
                "acceptable_variants": [
                        "A",
                        "A.",
                        "360 m2",
                        "360 mét vuông",
                        "360",
                        "A. 360 m2"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Bị kích thích bởi số 18 xuất hiện trong đề bài và tiện tay nhân 24 x 18.",
                "executive_function_scaffolding": "Luyện kỹ năng ức chế (Inhibition): gạch một đường đỏ mảnh qua cụm từ 'cạnh bên là 18 m' vì nó không nằm trong công thức.",
                "visual_or_concrete_aid": "Hình vẽ bình hành có đường cao hạ vuông góc nét đứt màu đỏ rõ rệt."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Nhớ Công Thức Diện Tích",
                        "action_verb": "Nhớ",
                        "atomic_instruction": "Nhớ công thức: diện tích bằng đáy nhân chiều cao.",
                        "text": "Nhớ công thức: diện tích bằng đáy nhân chiều cao.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Công thức diện tích hình bình hành là:",
                                "options": [
                                        "S = a x h",
                                        "S = (a + b) x 2",
                                        "S = a x b"
                                ]
                        },
                        "duration_sec": 85,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Diện tích bình hành = Đáy nhân Chiều cao."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "S = a x h",
                                "feedback_on_error": "S = a x h (đáy nhân chiều cao) con nhé!"
                        },
                        "mathematical_or_logical_goal": "Xác định công thức chuẩn",
                        "intermediate_output": "S = đáy x chiều cao",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Bỏ Dữ Kiện Nhiễu",
                        "action_verb": "Lọc",
                        "atomic_instruction": "Chọn đáy 24m, cao 15m và bỏ cạnh bên 18m.",
                        "text": "Chọn đáy 24m, cao 15m và bỏ cạnh bên 18m.",
                        "type": "checkbox",
                        "ui_type": "checkbox",
                        "ui_data": {
                                "prompt_text": "Dữ kiện 18m cạnh bên là chi tiết gây nhiễu, cần bỏ qua?",
                                "options": [
                                        "Đúng, chỉ lấy 24m đáy và 15m chiều cao"
                                ]
                        },
                        "duration_sec": 85,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Không nhân với cạnh bên 18m nha."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": true,
                                "feedback_on_error": "Đúng rồi, chỉ dùng đáy 24m và cao 15m thôi!"
                        },
                        "mathematical_or_logical_goal": "Khử nhiễu dữ kiện (Inhibition control)",
                        "intermediate_output": "a = 24; h = 15 (bỏ 18)",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Thực Hiện Phép Nhân",
                        "action_verb": "Tính",
                        "atomic_instruction": "Tính 24 nhân 15 bằng bao nhiêu mét vuông.",
                        "text": "Tính 24 nhân 15 bằng bao nhiêu mét vuông.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "24 x 15 = ? (m2)",
                                "placeholder": "Nhập diện tích..."
                        },
                        "duration_sec": 85,
                        "immediate_reinforcer": {
                                "visual_asset": "milo_thumbs_up",
                                "audio_cue": "gentle_pop_success",
                                "dopamine_points": 35
                        },
                        "hints": [
                                "24 x 10 = 240; 24 x 5 = 120; 240 + 120 = 360."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "360",
                                "feedback_on_error": "24 nhân 15 bằng 360 m2 con nhé!"
                        },
                        "mathematical_or_logical_goal": "Thực hiện phép tính nhân số có 2 chữ số",
                        "intermediate_output": "360 m2",
                        "is_final_step": false
                },
                {
                        "step_id": 4,
                        "badge": "Chọn Phương Án A",
                        "action_verb": "Chọn",
                        "atomic_instruction": "Chọn phương án A có diện tích 360 m2.",
                        "text": "Chọn phương án A có diện tích 360 m2.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Chọn đáp án trắc nghiệm đúng:",
                                "options": [
                                        "A. 360 m2",
                                        "B. 432 m2",
                                        "C. 78 m",
                                        "D. 180 m2"
                                ]
                        },
                        "duration_sec": 85,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 45
                        },
                        "hints": [
                                "Chọn phương án A. 360 m2."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "A. 360 m2",
                                "feedback_on_error": "Phương án A là đáp án chính xác!"
                        },
                        "mathematical_or_logical_goal": "Khẳng định đáp án",
                        "intermediate_output": "Phương án A",
                        "is_final_step": true
                }
        ]
},

      // #20. Tiếng Anh (Grade 4): English Reading: Hoạt động của mẹ Peter trong bếp
      'G4_ENG_20':   "id": "G4_ENG_20",
        "grade": 4,
        "subject": "Tiếng Anh",
        "cat": "eng",
        "catName": "Tiếng Anh Tiểu Học",
        "icon": "🥞",
        "title": "English Reading: Hoạt động của mẹ Peter trong bếp",
        "island": "study",
        "reward": 130,
        "stepSeconds": 80,
        "original_text": "Read the passage:\n'It is Sunday morning. Peter's family is at home. His father is washing the car in the garage. His mother is making pancakes in the kitchen. Peter and his sister, Linda, are playing board games in the living room.'\nQuestion: Where is Peter's mother and what is she doing?\nA. In the garage, washing the car.\nB. In the kitchen, making pancakes.\nC. In the living room, playing board games.\nD. In the bedroom, reading a book.",
        "final_answer": {
                "value": "B",
                "unit": null,
                "normalized_display": "B. In the kitchen, making pancakes.",
                "acceptable_variants": [
                        "B",
                        "B.",
                        "In the kitchen, making pancakes.",
                        "B. In the kitchen, making pancakes."
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Quá tải khi đọc 3 nhân vật khác nhau trong cùng một đoạn văn ngắn và ghép lộn người này vào việc người kia.",
                "executive_function_scaffolding": "Đặt bộ lọc: Bỏ qua câu về Father, bỏ qua câu về Peter/Linda, chỉ đọc câu có Mother.",
                "visual_or_concrete_aid": "Bản đồ căn nhà cắt lớp với các phòng và biểu tượng người ở từng phòng."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Xác Định Đối Tượng Mẹ",
                        "action_verb": "Tìm",
                        "atomic_instruction": "Tìm tên Peter's mother trong câu hỏi.",
                        "text": "Tìm tên Peter's mother trong câu hỏi.",
                        "type": "highlight",
                        "ui_type": "highlight",
                        "ui_data": {
                                "prompt_text": "Tìm nhân vật được hỏi trong câu:",
                                "highlight_target_segments": [
                                        "Peter's mother"
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Câu hỏi hỏi về mẹ của Peter."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": [
                                        "Peter's mother"
                                ],
                                "feedback_on_error": "Đối tượng là Peter's mother nha!"
                        },
                        "mathematical_or_logical_goal": "Xác định thực thể mục tiêu",
                        "intermediate_output": "Target: Peter's mother",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Dò Câu Chứa His Mother",
                        "action_verb": "Dò",
                        "atomic_instruction": "Dò câu có cụm making pancakes in the kitchen.",
                        "text": "Dò câu có cụm making pancakes in the kitchen.",
                        "type": "highlight",
                        "ui_type": "highlight",
                        "ui_data": {
                                "prompt_text": "Tìm câu miêu tả mẹ của Peter:",
                                "highlight_target_segments": [
                                        "His mother is making pancakes in the kitchen."
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 35
                        },
                        "hints": [
                                "Mẹ làm bánh kếp trong bếp: kitchen & pancakes."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": [
                                        "His mother is making pancakes in the kitchen."
                                ],
                                "feedback_on_error": "His mother is making pancakes in the kitchen."
                        },
                        "mathematical_or_logical_goal": "Định vị vị trí thông tin",
                        "intermediate_output": "'making pancakes in the kitchen'",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Chọn Phương Án B",
                        "action_verb": "Chọn",
                        "atomic_instruction": "Chọn phương án B có địa điểm và hành động.",
                        "text": "Chọn phương án B có địa điểm và hành động.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Chọn phương án trắc nghiệm đúng:",
                                "options": [
                                        "A. In the garage, washing the car.",
                                        "B. In the kitchen, making pancakes.",
                                        "C. In the living room, playing board games.",
                                        "D. In the bedroom, reading a book."
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 45
                        },
                        "hints": [
                                "Phương án B: In the kitchen, making pancakes."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "B. In the kitchen, making pancakes.",
                                "feedback_on_error": "Phương án B là đáp án chính xác!"
                        },
                        "mathematical_or_logical_goal": "Khớp nối thông tin đa thành phần",
                        "intermediate_output": "Phương án B",
                        "is_final_step": true
                }
        ]
},

      // #21. Toán (Grade 5): Toán chuyển động đều: Ô tô và xe máy gặp nhau
      'G5_MATH_21':   "id": "G5_MATH_21",
        "grade": 5,
        "subject": "Toán",
        "cat": "math",
        "catName": "Toán GDPT 2018",
        "icon": "🚗",
        "title": "Toán chuyển động đều: Ô tô và xe máy gặp nhau",
        "island": "study",
        "reward": 160,
        "stepSeconds": 100,
        "original_text": "Quãng đường AB dài 180 km. Cùng một lúc vào lúc 7 giờ sáng, một ô tô đi từ A về B với vận tốc 50 km/giờ và một xe máy đi từ B về A với vận tốc 40 km/giờ. Hỏi:\na) Sau bao lâu hai xe gặp nhau?\nb) Hai xe gặp nhau lúc mấy giờ?",
        "final_answer": {
                "value": "a) 2 giờ; b) 9 giờ",
                "unit": null,
                "normalized_display": "a) 2 giờ; b) 9 giờ sáng",
                "acceptable_variants": [
                        "a) 2 giờ; b) 9 giờ sáng",
                        "a) 2 giờ, b) 9 giờ",
                        "2 giờ và 9 giờ",
                        "2 giờ; 9 giờ",
                        "2 giờ, 9 giờ sáng",
                        "Sau 2 giờ; Lúc 9 giờ"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Nhầm lẫn giữa 'thời gian đi' (khoảng thời gian 2 giờ) và 'thời điểm gặp' (mốc thời gian 9 giờ); nhầm vận tốc tổng với vận tốc hiệu.",
                "executive_function_scaffolding": "Tách thành 2 chặng độc lập với câu hỏi con rõ ràng: Chặng 1: Tìm số giờ đi; Chặng 2: Cộng vào 7 giờ sáng.",
                "visual_or_concrete_aid": "Trục thời gian và sơ đồ đoạn đường với hai mũi tên xe chạy hướng vào nhau."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Tính Tổng Vận Tốc",
                        "action_verb": "Cộng",
                        "atomic_instruction": "Cộng vận tốc ô tô 50 và xe máy 40.",
                        "text": "Cộng vận tốc ô tô 50 và xe máy 40.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "50 + 40 = ? (km/giờ)",
                                "placeholder": "Nhập tổng vận tốc..."
                        },
                        "duration_sec": 100,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Hai xe đi ngược chiều, cộng hai vận tốc lại."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "90",
                                "feedback_on_error": "50 + 40 = 90 km/giờ con nhé!"
                        },
                        "mathematical_or_logical_goal": "Tính tổng vận tốc hai chuyển động",
                        "intermediate_output": "50 + 40 = 90 (km/giờ)",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Tính Thời Gian Gặp",
                        "action_verb": "Chia",
                        "atomic_instruction": "Lấy quãng đường 180 chia tổng vận tốc 90.",
                        "text": "Lấy quãng đường 180 chia tổng vận tốc 90.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "180 : 90 = ? (giờ)",
                                "placeholder": "Nhập thời gian đi..."
                        },
                        "duration_sec": 100,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 35
                        },
                        "hints": [
                                "180 chia 90 bằng 2 giờ."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "2",
                                "feedback_on_error": "Sau 2 giờ hai xe gặp nhau con nhé!"
                        },
                        "mathematical_or_logical_goal": "Tính thời gian gặp nhau (t = s : v_tong)",
                        "intermediate_output": "180 : 90 = 2 (giờ)",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Tính Thời Điểm Gặp",
                        "action_verb": "Cộng",
                        "atomic_instruction": "Cộng giờ xuất phát 7 giờ với 2 giờ đi.",
                        "text": "Cộng giờ xuất phát 7 giờ với 2 giờ đi.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "7 + 2 = ? (giờ sáng)",
                                "placeholder": "Nhập thời điểm gặp nhau..."
                        },
                        "duration_sec": 100,
                        "immediate_reinforcer": {
                                "visual_asset": "milo_thumbs_up",
                                "audio_cue": "gentle_pop_success",
                                "dopamine_points": 35
                        },
                        "hints": [
                                "Xuất phát lúc 7 giờ, đi 2 giờ là 9 giờ sáng."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "9",
                                "feedback_on_error": "Hai xe gặp nhau lúc 9 giờ sáng!"
                        },
                        "mathematical_or_logical_goal": "Chuyển đổi thời lượng sang mốc thời gian",
                        "intermediate_output": "7 + 2 = 9 (giờ sáng)",
                        "is_final_step": false
                },
                {
                        "step_id": 4,
                        "badge": "Ghi Đủ Hai Câu",
                        "action_verb": "Kết_luận",
                        "atomic_instruction": "Chọn đáp án ghi rõ cả 2 giờ và 9 giờ.",
                        "text": "Chọn đáp án ghi rõ cả 2 giờ và 9 giờ.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Đáp số câu a và câu b là:",
                                "options": [
                                        "a) 2 giờ; b) 9 giờ sáng",
                                        "a) 3 giờ; b) 10 giờ sáng",
                                        "a) 2 giờ; b) 8 giờ sáng"
                                ]
                        },
                        "duration_sec": 100,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 50
                        },
                        "hints": [
                                "a) 2 giờ; b) 9 giờ sáng."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "a) 2 giờ; b) 9 giờ sáng",
                                "feedback_on_error": "Đáp số là a) 2 giờ; b) 9 giờ sáng!"
                        },
                        "mathematical_or_logical_goal": "Kết luận toàn diện đa câu hỏi",
                        "intermediate_output": "a) 2 giờ; b) 9 giờ sáng",
                        "is_final_step": true
                }
        ]
},

      // #22. Toán (Grade 5): Thể tích bể nước hình hộp chữ nhật và tính lít nước
      'G5_MATH_22':   "id": "G5_MATH_22",
        "grade": 5,
        "subject": "Toán",
        "cat": "math",
        "catName": "Toán GDPT 2018",
        "icon": "📦",
        "title": "Thể tích bể nước hình hộp chữ nhật và tính lít nước",
        "island": "study",
        "reward": 160,
        "stepSeconds": 100,
        "original_text": "Một bể nước dạng hình hộp chữ nhật có kích thước bên trong lòng bể là: chiều dài 2 m, chiều rộng 1,5 m và chiều cao 1,2 m. Hiện tại lượng nước trong bể chiếm 60% thể tích bể. Hỏi trong bể đang có bao nhiêu lít nước? (Biết 1 dm3 = 1 lít).",
        "final_answer": {
                "value": 2160,
                "unit": "lít",
                "normalized_display": "2160 lít",
                "acceptable_variants": [
                        "2160",
                        "2160 lít",
                        "2160 l",
                        "2160 lít nước"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Quên đổi từ m3 sang dm3 (lấy 3,6 x 60% = 2,16 lít) hoặc nhân nhầm hệ số đổi đơn vị thể tích là 100 thay vì 1000.",
                "executive_function_scaffolding": "Mẹo neo trí nhớ: 'Mét khối sang Đề-xi-mét khối phải có 3 chữ số 0 (nhân 1000)'.",
                "visual_or_concrete_aid": "Bể nước 3D có vạch nước dâng lên mức 60%."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Tính Thể Tích Bể",
                        "action_verb": "Nhân",
                        "atomic_instruction": "Nhân 2m với 1,5m rồi nhân 1,2m chiều cao.",
                        "text": "Nhân 2m với 1,5m rồi nhân 1,2m chiều cao.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "2 x 1,5 x 1,2 = ? (m3)",
                                "placeholder": "Nhập thể tích bể..."
                        },
                        "duration_sec": 100,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "2 x 1,5 = 3; 3 x 1,2 = 3,6 m3."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "3.6",
                                "feedback_on_error": "Thể tích là 3,6 m3 con nhé!"
                        },
                        "mathematical_or_logical_goal": "Tính thể tích hình hộp chữ nhật",
                        "intermediate_output": "2 x 1,5 x 1,2 = 3,6 (m3)",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Đổi Mét Khối Sang Lít",
                        "action_verb": "Đổi",
                        "atomic_instruction": "Đổi 3,6 mét khối sang 3600 lít.",
                        "text": "Đổi 3,6 mét khối sang 3600 lít.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "1 m3 = 1000 lít, vậy 3,6 m3 = ? lít",
                                "options": [
                                        "3,6 m3 = 3600 lít",
                                        "3,6 m3 = 360 lít",
                                        "3,6 m3 = 36000 lít"
                                ]
                        },
                        "duration_sec": 100,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "Nhân 3,6 với 1000 ra 3600 lít."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "3,6 m3 = 3600 lít",
                                "feedback_on_error": "3,6 m3 = 3600 dm3 = 3600 lít nha!"
                        },
                        "mathematical_or_logical_goal": "Đổi đơn vị đo thể tích: 1 m3 = 1000 dm3",
                        "intermediate_output": "3,6 m3 = 3600 dm3 = 3600 lít",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Tính 60% Lượng Nước",
                        "action_verb": "Tính",
                        "atomic_instruction": "Lấy 3600 lít nhân 60 rồi chia 100.",
                        "text": "Lấy 3600 lít nhân 60 rồi chia 100.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "3600 x 60 : 100 = ? (lít nước)",
                                "placeholder": "Nhập lượng nước có trong bể..."
                        },
                        "duration_sec": 100,
                        "immediate_reinforcer": {
                                "visual_asset": "milo_thumbs_up",
                                "audio_cue": "gentle_pop_success",
                                "dopamine_points": 35
                        },
                        "hints": [
                                "3600 x 0,6 = 2160 lít."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "2160",
                                "feedback_on_error": "Lượng nước là 2160 lít con nha!"
                        },
                        "mathematical_or_logical_goal": "Tìm giá trị phần trăm của một số",
                        "intermediate_output": "3600 x 60 / 100 = 2160 (lít)",
                        "is_final_step": false
                },
                {
                        "step_id": 4,
                        "badge": "Ghi Đáp Số Lít",
                        "action_verb": "Kết_luận",
                        "atomic_instruction": "Ghi đáp số 2160 lít nước trong bể.",
                        "text": "Ghi đáp số 2160 lít nước trong bể.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Đáp số lượng nước đang có là:",
                                "options": [
                                        "2160 lít",
                                        "3600 lít",
                                        "216 lít"
                                ]
                        },
                        "duration_sec": 100,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 50
                        },
                        "hints": [
                                "Đáp số là 2160 lít."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "2160 lít",
                                "feedback_on_error": "Đáp số là 2160 lít nước!"
                        },
                        "mathematical_or_logical_goal": "Kết luận bài toán",
                        "intermediate_output": "2160 lít",
                        "is_final_step": true
                }
        ]
},

      // #23. Tiếng Việt (Grade 5): Đọc hiểu: Bài học kiên trì rèn luyện nét chữ
      'G5_VIET_23':   "id": "G5_VIET_23",
        "grade": 5,
        "subject": "Tiếng Việt",
        "cat": "viet",
        "catName": "Tiếng Việt GDPT",
        "icon": "✍️",
        "title": "Đọc hiểu: Bài học kiên trì rèn luyện nét chữ",
        "island": "study",
        "reward": 150,
        "stepSeconds": 90,
        "original_text": "Đọc đoạn văn sau:\n'Nhờ biết kiên trì rèn luyện từng nét chữ mỗi ngày và không nản lòng trước những trang giấy bị lem mực, cuối cùng Cao Bá Quát đã sửa được tật viết chữ xấu, trở thành người nổi tiếng khắp vùng về tài văn hay chữ tốt.'\nCâu hỏi: Nguyên nhân chính nào giúp Cao Bá Quát từ một người viết chữ rất xấu trở thành người nổi tiếng về chữ tốt? Bài học em rút ra từ câu chuyện trên là gì?",
        "final_answer": {
                "value": "Kiên trì rèn luyện mỗi ngày, không nản lòng trước khó khăn",
                "unit": null,
                "normalized_display": "Kiên trì rèn luyện mỗi ngày, không nản lòng; bài học: có ý chí, kiên nhẫn thì sẽ vượt qua khó khăn để thành công",
                "acceptable_variants": [
                        "kiên trì rèn luyện",
                        "lòng kiên trì rèn luyện mỗi ngày và không nản lòng",
                        "kiên trì, không nản chí",
                        "có ý chí và lòng kiên trì",
                        "kiên trì",
                        "không nản lòng"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Chỉ trả lời được một nửa câu hỏi (chỉ nêu nguyên nhân hoặc chỉ nêu bài học) do trí nhớ làm việc bị quá tải bởi câu hỏi kép.",
                "executive_function_scaffolding": "Phân tách rành mạch thành 2 phần: [Phần 1: Nguyên nhân là gì?] và [Phần 2: Bài học rút ra là gì?].",
                "visual_or_concrete_aid": "Biểu tượng mũi tên kép nối từ Cố Gắng -> Thành Quả."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Tìm Vế Nguyên Nhân",
                        "action_verb": "Tìm",
                        "atomic_instruction": "Tìm vế kiên trì rèn luyện sau chữ Nhờ.",
                        "text": "Tìm vế kiên trì rèn luyện sau chữ Nhờ.",
                        "type": "highlight",
                        "ui_type": "highlight",
                        "ui_data": {
                                "prompt_text": "Tìm vế nguyên nhân dẫn đến thành công của bạn nhỏ:",
                                "highlight_target_segments": [
                                        "kiên trì rèn luyện từng nét chữ mỗi ngày và không nản lòng"
                                ]
                        },
                        "duration_sec": 90,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "Nguyên nhân là kiên trì rèn luyện mỗi ngày."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": [
                                        "kiên trì rèn luyện từng nét chữ mỗi ngày và không nản lòng"
                                ],
                                "feedback_on_error": "Nguyên nhân là kiên trì rèn luyện mỗi ngày, không nản lòng!"
                        },
                        "mathematical_or_logical_goal": "Bóc tách mối quan hệ nhân quả",
                        "intermediate_output": "Nguyên nhân: kiên trì rèn luyện, không nản lòng",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Rút Ra Bài Học",
                        "action_verb": "Khái_quát",
                        "atomic_instruction": "Khái quát bài học kiên trì vượt khó thành công.",
                        "text": "Khái quát bài học kiên trì vượt khó thành công.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Câu chuyện gửi gắm bài học cuộc sống gì?",
                                "options": [
                                        "Có ý chí, kiên nhẫn thì sẽ vượt qua khó khăn để thành công",
                                        "Chỉ cần viết nhanh",
                                        "Không cần luyện tập"
                                ]
                        },
                        "duration_sec": 90,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 35
                        },
                        "hints": [
                                "Bài học về lòng kiên trì vượt khó."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "Có ý chí, kiên nhẫn thì sẽ vượt qua khó khăn để thành công",
                                "feedback_on_error": "Có ý chí kiên nhẫn thì sẽ vượt qua khó khăn để thành công!"
                        },
                        "mathematical_or_logical_goal": "Đúc kết thông điệp đạo đức",
                        "intermediate_output": "Bài học: kiên trì, có ý chí vượt khó thì sẽ thành công",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Chọn Đáp Án Đầy Đủ",
                        "action_verb": "Tổng_hợp",
                        "atomic_instruction": "Chọn câu trả lời có đủ nguyên nhân và bài học.",
                        "text": "Chọn câu trả lời có đủ nguyên nhân và bài học.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Chọn đáp án tổng hợp hoàn chỉnh:",
                                "options": [
                                        "Kiên trì rèn luyện mỗi ngày, không nản lòng; bài học: có ý chí, kiên nhẫn thì sẽ vượt qua khó khăn để thành công",
                                        "Chỉ cần rèn chữ đẹp là đủ",
                                        "Thành công là do may mắn"
                                ]
                        },
                        "duration_sec": 90,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 50
                        },
                        "hints": [
                                "Chọn đáp án đầy đủ cả 2 vế."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "Kiên trì rèn luyện mỗi ngày, không nản lòng; bài học: có ý chí, kiên nhẫn thì sẽ vượt qua khó khăn để thành công",
                                "feedback_on_error": "Chọn đáp án có cả nguyên nhân và bài học nhé!"
                        },
                        "mathematical_or_logical_goal": "Diễn đạt câu trả lời trọn vẹn",
                        "intermediate_output": "Kiên trì rèn luyện mỗi ngày, không nản lòng; bài học về ý chí và sự kiên trì",
                        "is_final_step": true
                }
        ]
},

      // #24. Toán (Grade 5): Bài toán giảm giá 2 lần của chiếc cặp sách (Tỉ số %)
      'G5_MCQ_24':   "id": "G5_MCQ_24",
        "grade": 5,
        "subject": "Toán",
        "cat": "math",
        "catName": "Toán GDPT 2018",
        "icon": "🎒",
        "title": "Bài toán giảm giá 2 lần của chiếc cặp sách (Tỉ số %)",
        "island": "study",
        "reward": 150,
        "stepSeconds": 90,
        "original_text": "Giá một chiếc cặp sách đầu năm là 200 000 đồng. Nhân dịp khai giảng, cửa hàng giảm giá 15%. Đến tuần lễ vàng, cửa hàng lại giảm tiếp 10% trên giá đã giảm. Hỏi sau hai lần giảm giá, chiếc cặp sách đó có giá là bao nhiêu?\nA. 150 000 đồng\nB. 153 000 đồng\nC. 170 000 đồng\nD. 147 000 đồng",
        "final_answer": {
                "value": "B",
                "unit": null,
                "normalized_display": "B. 153 000 đồng",
                "acceptable_variants": [
                        "B",
                        "B.",
                        "153 000 đồng",
                        "153 000",
                        "153000",
                        "B. 153 000 đồng"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Bị cám dỗ bởi phép tính nhẩm nhanh 15 + 10 = 25% dẫn thẳng vào bẫy đáp án A.",
                "executive_function_scaffolding": "Thiết lập chốt chặn quy tắc: 'Không được cộng hai tỉ số phần trăm khi gốc tính tiền thay đổi'.",
                "visual_or_concrete_aid": "Nhãn giá hạ bậc thang: Giá 200 000 -> Giảm 15% còn 170 000 -> Giảm 10% còn 153 000."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Giá Sau Giảm Lần Một",
                        "action_verb": "Tính",
                        "atomic_instruction": "Tính 200 000 nhân 85% ra giá lần một.",
                        "text": "Tính 200 000 nhân 85% ra giá lần một.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "200 000 x 0,85 = ? (đồng)",
                                "placeholder": "Nhập giá lần 1..."
                        },
                        "duration_sec": 90,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "200 000 x (100% - 15%) = 170 000 đồng."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "170000",
                                "feedback_on_error": "Giá sau lần 1 là 170 000 đồng con nhé!"
                        },
                        "mathematical_or_logical_goal": "Tính giá trị sau lần chiết khấu 1",
                        "intermediate_output": "200 000 x 0,85 = 170 000 (đồng)",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Giá Sau Giảm Lần Hai",
                        "action_verb": "Tính",
                        "atomic_instruction": "Tính 170 000 nhân 90% ra giá lần hai.",
                        "text": "Tính 170 000 nhân 90% ra giá lần hai.",
                        "type": "text_input",
                        "ui_type": "text_input",
                        "ui_data": {
                                "prompt_text": "170 000 x 0,9 = ? (đồng)",
                                "placeholder": "Nhập giá lần 2..."
                        },
                        "duration_sec": 90,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 35
                        },
                        "hints": [
                                "170 000 x (100% - 10%) = 153 000 đồng."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "153000",
                                "feedback_on_error": "Giá cuối cùng là 153 000 đồng nha!"
                        },
                        "mathematical_or_logical_goal": "Tính giá trị sau lần chiết khấu 2",
                        "intermediate_output": "170 000 x 0,9 = 153 000 (đồng)",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Chọn Phương Án B",
                        "action_verb": "Chọn",
                        "atomic_instruction": "Chọn phương án B có giá 153 000 đồng.",
                        "text": "Chọn phương án B có giá 153 000 đồng.",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Chọn phương án trắc nghiệm đúng:",
                                "options": [
                                        "A. 150 000 đồng",
                                        "B. 153 000 đồng",
                                        "C. 170 000 đồng",
                                        "D. 147 000 đồng"
                                ]
                        },
                        "duration_sec": 90,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 50
                        },
                        "hints": [
                                "Phương án B: 153 000 đồng."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "B. 153 000 đồng",
                                "feedback_on_error": "Phương án B là đáp án chính xác!"
                        },
                        "mathematical_or_logical_goal": "Khẳng định đáp án",
                        "intermediate_output": "Phương án B",
                        "is_final_step": true
                }
        ]
},

      // #25. Tiếng Anh (Grade 5): English Reading: Chuyến đi Đà Nẵng của Nam (By plane)
      'G5_ENG_25':   "id": "G5_ENG_25",
        "grade": 5,
        "subject": "Tiếng Anh",
        "cat": "eng",
        "catName": "Tiếng Anh Tiểu Học",
        "icon": "✈️",
        "title": "English Reading: Chuyến đi Đà Nẵng của Nam (By plane)",
        "island": "study",
        "reward": 140,
        "stepSeconds": 80,
        "original_text": "Read the story:\n'Last summer, Nam went to Da Nang with his parents. They visited Ba Na Hills and took a cable car to the Golden Bridge. The weather was cool and sunny. Nam took lots of beautiful photos. On the last day, they bought some seafood and souvenirs before taking a plane back to Ha Noi.'\nQuestion: How did Nam and his family travel back to Ha Noi?\nA. By train\nB. By coach\nC. By plane\nD. By boat",
        "final_answer": {
                "value": "C",
                "unit": null,
                "normalized_display": "C. By plane",
                "acceptable_variants": [
                        "C",
                        "C.",
                        "By plane",
                        "plane",
                        "C. By plane"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Đọc lướt thấy 'cable car' ở câu 2 và vội vã suy đoán hoặc chọn sai phương tiện.",
                "executive_function_scaffolding": "Neo từ khóa thời gian: 'On the last day' + 'back to Ha Noi'.",
                "visual_or_concrete_aid": "Biểu tượng máy bay gắn liền với chiều mũi tên bay từ Đà Nẵng về Hà Nội."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Xác Định Câu Hỏi",
                        "action_verb": "Tìm",
                        "atomic_instruction": "Tìm phương tiện về Hà Nội trong câu hỏi.",
                        "text": "Tìm phương tiện về Hà Nội trong câu hỏi.",
                        "type": "highlight",
                        "ui_type": "highlight",
                        "ui_data": {
                                "prompt_text": "Tìm cụm từ 'travel back to Ha Noi' trong câu hỏi:",
                                "highlight_target_segments": [
                                        "travel back to Ha Noi"
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Câu hỏi hỏi phương tiện đi về Hà Nội."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": [
                                        "travel back to Ha Noi"
                                ],
                                "feedback_on_error": "Tìm phương tiện travel back to Ha Noi con nha!"
                        },
                        "mathematical_or_logical_goal": "Xác định mục tiêu tìm kiếm thông tin",
                        "intermediate_output": "Target: transport back to Ha Noi",
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Dò Cụm Taking A Plane",
                        "action_verb": "Dò",
                        "atomic_instruction": "Dò câu cuối chứa taking a plane back to Ha Noi.",
                        "text": "Dò câu cuối chứa taking a plane back to Ha Noi.",
                        "type": "highlight",
                        "ui_type": "highlight",
                        "ui_data": {
                                "prompt_text": "Tìm phương tiện trong câu cuối của đoạn văn:",
                                "highlight_target_segments": [
                                        "taking a plane"
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 35
                        },
                        "hints": [
                                "Nam đi máy bay: taking a plane."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": [
                                        "taking a plane"
                                ],
                                "feedback_on_error": "Cụm từ là 'taking a plane' nhé!"
                        },
                        "mathematical_or_logical_goal": "Định vị dẫn chứng văn bản",
                        "intermediate_output": "'taking a plane'",
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Chọn Phương Án C",
                        "action_verb": "Chọn",
                        "atomic_instruction": "Chọn phương án C đi bằng máy bay (By plane).",
                        "text": "Chọn phương án C đi bằng máy bay (By plane).",
                        "type": "single_choice",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Chọn phương án trắc nghiệm đúng:",
                                "options": [
                                        "A. By train",
                                        "B. By coach",
                                        "C. By plane",
                                        "D. By boat"
                                ]
                        },
                        "duration_sec": 80,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 45
                        },
                        "hints": [
                                "Taking a plane tương ứng với By plane."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "C. By plane",
                                "feedback_on_error": "Phương án C. By plane là chính xác!"
                        },
                        "mathematical_or_logical_goal": "Quy đổi ngữ nghĩa và chọn phương án",
                        "intermediate_output": "Phương án C",
                        "is_final_step": true
                }
        ]
},

      // #26. hoat_dong_trai_nghiem (Grade 1): Dọn bàn học gọn gàng trong 5 phút
      'chore_desk':   "id": "chore_desk",
        "grade": 1,
        "subject": "hoat_dong_trai_nghiem",
        "cat": "chore",
        "catName": "Hoạt Động Trải Nghiệm",
        "icon": "🧹",
        "title": "Dọn bàn học gọn gàng trong 5 phút",
        "island": "routine",
        "reward": 120,
        "stepSeconds": 60,
        "original_text": "Sau khi học bài xong, em hãy tự giác dọn dẹp góc học tập cho ngăn nắp: cắm bút vào ống, gom giấy vụn bỏ vào sọt rác, xếp sách vở gọn gàng góc trái và lau sạch mặt bàn.",
        "final_answer": {
                "value": "Bàn học gọn gàng, sạch sẽ",
                "unit": null,
                "normalized_display": "Bàn học gọn gàng, sạch sẽ",
                "acceptable_variants": [
                        "gọn gàng",
                        "sạch sẽ",
                        "ngăn nắp"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Trẻ dễ bị quá tải khi nhìn mặt bàn lộn xộn nhiều đồ vật cùng lúc (Visual Clutter Paralysis).",
                "executive_function_scaffolding": "Chia nhỏ thành 4 vi hành động đơn lẻ theo thứ tự: bút -> rác -> sách -> lau bàn.",
                "visual_or_concrete_aid": "Hoạt ảnh tương tác từng món đồ biến mất vào đúng vị trí khi chạm vào."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Cắm bút vào ống",
                        "action_verb": "Cắm_bút",
                        "atomic_instruction": "Chạm vào 3 cây bút bừa bộn trên bàn.",
                        "text": "Chạm vào 3 cây bút bừa bộn trên bàn.",
                        "type": "chore_pens",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Chạm vào 3 cây bút đang nằm bừa bộn trên bàn để cắm vào ống:"
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Chạm vào bút chì, bút bi và bút sáp để cất gọn nhé."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": "pen3",
                                "feedback_on_error": "Con cất đủ 3 cây bút vào ống nhé!"
                        },
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Gom giấy vụn",
                        "action_verb": "Gom_rác",
                        "atomic_instruction": "Chạm vào các mảnh giấy bỏ vào sọt rác.",
                        "text": "Chạm vào các mảnh giấy bỏ vào sọt rác.",
                        "type": "chore_trash",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Chạm vào mảnh giấy nháp bỏ vào sọt rác dưới gầm bàn:"
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Bấm nút bỏ giấy vào thùng rác nào."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": true,
                                "feedback_on_error": "Mẩu giấy nháp cần được bỏ vào thùng rác nha!"
                        },
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Xếp sách vở",
                        "action_verb": "Xếp_sách",
                        "atomic_instruction": "Chạm vào chồng sách xếp ngay ngắn góc trái.",
                        "text": "Chạm vào chồng sách xếp ngay ngắn góc trái.",
                        "type": "chore_books",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Chạm vào chồng sách để xếp ngay ngắn vào góc trái:"
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "milo_thumbs_up",
                                "audio_cue": "gentle_pop_success",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "Xếp các cuốn sách ngay ngắn thẳng hàng góc trái."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": true,
                                "feedback_on_error": "Xếp sách thẳng hàng cùng Milo nhé!"
                        },
                        "is_final_step": false
                },
                {
                        "step_id": 4,
                        "badge": "Lau sạch mặt bàn",
                        "action_verb": "Lau_bàn",
                        "atomic_instruction": "Chạm khăn lau để mặt bàn sáng bóng sạch sẽ.",
                        "text": "Chạm khăn lau để mặt bàn sáng bóng sạch sẽ.",
                        "type": "chore_wipe",
                        "ui_type": "single_choice",
                        "ui_data": {
                                "prompt_text": "Chạm vào khăn lau để mặt bàn sáng bóng nhé:"
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 40
                        },
                        "hints": [
                                "Bấm khăn lau để mặt bàn sáng bóng lấp lánh."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": true,
                                "feedback_on_error": "Dùng khăn lau sạch vết bụi trên mặt bàn nào!"
                        },
                        "is_final_step": true
                }
        ]
},

      // #27. hoat_dong_trai_nghiem (Grade 1): Đánh răng đúng cách 2 phút buổi tối
      'chore_teeth':   "id": "chore_teeth",
        "grade": 1,
        "subject": "hoat_dong_trai_nghiem",
        "cat": "chore",
        "catName": "Vệ Sinh Cá Nhân",
        "icon": "🪥",
        "title": "Đánh răng đúng cách 2 phút buổi tối",
        "island": "routine",
        "reward": 100,
        "stepSeconds": 45,
        "original_text": "Em hãy tự giác đánh răng sạch sẽ trước khi đi ngủ: lấy kem bằng hạt đậu, chải đều mặt ngoài, trong và nhai trong 2 phút, sau đó súc miệng sạch và cất bàn chải vào cốc.",
        "final_answer": {
                "value": "Răng miệng sạch thơm tho",
                "unit": null,
                "normalized_display": "Răng miệng sạch thơm tho",
                "acceptable_variants": [
                        "sạch sẽ",
                        "thơm tho",
                        "trắng sáng"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Trẻ dễ vội vã đánh qua loa dưới 30 giây do bồn chồn cơ thể.",
                "executive_function_scaffolding": "Đĩa đồng hồ đếm ngược êm dịu chia 3 nhịp: chuẩn bị -> chải 2 phút -> súc miệng.",
                "visual_or_concrete_aid": "Hoạt ảnh bọt xà phòng trắng xoay tròn trên hàm răng."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Lấy kem đánh răng",
                        "action_verb": "Lấy_kem",
                        "atomic_instruction": "Lấy lượng kem bằng một hạt đậu nhỏ.",
                        "text": "Lấy lượng kem bằng một hạt đậu nhỏ.",
                        "type": "generic",
                        "ui_type": "checkbox",
                        "ui_data": {
                                "prompt_text": "Lấy lượng kem vừa đủ bằng một hạt đậu nhỏ lên đầu lông bàn chải:"
                        },
                        "duration_sec": 45,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Chỉ cần một hạt đậu nhỏ là đủ rồi con nhé."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": true,
                                "feedback_on_error": "Lấy kem bằng hạt đậu nhỏ thôi con nha!"
                        },
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Chải răng 2 phút",
                        "action_verb": "Chải_răng",
                        "atomic_instruction": "Chải xoay tròn mặt ngoài, trong và nhai.",
                        "text": "Chải xoay tròn mặt ngoài, trong và nhai.",
                        "type": "generic",
                        "ui_type": "checkbox",
                        "ui_data": {
                                "prompt_text": "Chải nhẹ nhàng xoay tròn mặt ngoài, mặt trong và mặt nhai:"
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 35
                        },
                        "hints": [
                                "Đưa bàn chải theo vòng tròn nhẹ nhàng khắp hàm răng."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": true,
                                "feedback_on_error": "Chải đủ mặt ngoài, mặt trong và mặt nhai nhé!"
                        },
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Súc miệng sạch",
                        "action_verb": "Súc_miệng",
                        "atomic_instruction": "Súc miệng sạch và cất bàn chải vào cốc.",
                        "text": "Súc miệng sạch và cất bàn chải vào cốc.",
                        "type": "generic",
                        "ui_type": "checkbox",
                        "ui_data": {
                                "prompt_text": "Súc miệng sạch sẽ với nước và cất bàn chải vào cốc thẳng đứng:"
                        },
                        "duration_sec": 45,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 40
                        },
                        "hints": [
                                "Súc miệng 2 lần với nước sạch và cất bàn chải."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": true,
                                "feedback_on_error": "Súc miệng thật sạch và cất cốc ngay ngắn nào!"
                        },
                        "is_final_step": true
                }
        ]
},

      // #28. hoat_dong_trai_nghiem (Grade 1): Tự chuẩn bị balo đi học ngày mai
      'chore_backpack':   "id": "chore_backpack",
        "grade": 1,
        "subject": "hoat_dong_trai_nghiem",
        "cat": "chore",
        "catName": "Tự Lập & Ngăn Nắp",
        "icon": "🎒",
        "title": "Tự chuẩn bị balo đi học ngày mai",
        "island": "routine",
        "reward": 120,
        "stepSeconds": 70,
        "original_text": "Trước khi đi ngủ, em hãy chuẩn bị balo theo thời khóa biểu ngày mai: xem sách vở cần mang, kiểm tra hộp bút có đủ 2 bút và 1 thước kẻ, và cho bình nước vào ngăn bên.",
        "final_answer": {
                "value": "Balo sẵn sàng đến trường",
                "unit": null,
                "normalized_display": "Balo sẵn sàng đến trường",
                "acceptable_variants": [
                        "sẵn sàng",
                        "đầy đủ",
                        "ngăn nắp"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Thường quên các món đồ nhỏ như bút chì, thước kẻ hoặc bình nước cá nhân.",
                "executive_function_scaffolding": "Checklist trực quan 4 điểm chốt chặn ngăn ngừa bỏ quên.",
                "visual_or_concrete_aid": "Biểu tượng balo mở nắp với các ngăn phát sáng tương ứng từng món đồ."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Thời khóa biểu",
                        "action_verb": "Xem",
                        "atomic_instruction": "Mở xem thời khóa biểu ngày mai đúng các môn.",
                        "text": "Mở xem thời khóa biểu ngày mai đúng các môn.",
                        "type": "generic",
                        "ui_type": "checkbox",
                        "ui_data": {
                                "prompt_text": "Mở xem thời khóa biểu ngày mai để chọn đúng các môn học:"
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Nhìn vào thời khóa biểu ngày mai xem có môn gì nhé."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": true,
                                "feedback_on_error": "Xem thời khóa biểu ngày mai cùng Milo nha!"
                        },
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Xếp sách vở",
                        "action_verb": "Xếp_sách",
                        "atomic_instruction": "Xếp sách to ở trong, vở mỏng ở ngoài.",
                        "text": "Xếp sách to ở trong, vở mỏng ở ngoài.",
                        "type": "generic",
                        "ui_type": "checkbox",
                        "ui_data": {
                                "prompt_text": "Xếp sách to ở trong cùng, vở bài tập mỏng ở phía ngoài:"
                        },
                        "duration_sec": 70,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Sách to xếp vào lưng cặp, vở mỏng ở ngoài."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": true,
                                "feedback_on_error": "Sách to ở trong, vở mỏng ở ngoài nha con!"
                        },
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Kiểm tra hộp bút",
                        "action_verb": "Kiểm_tra",
                        "atomic_instruction": "Kiểm tra đủ 2 bút mực, 1 bút chì, 1 thước.",
                        "text": "Kiểm tra đủ 2 bút mực, 1 bút chì, 1 thước.",
                        "type": "generic",
                        "ui_type": "checkbox",
                        "ui_data": {
                                "prompt_text": "Đảm bảo có đủ 2 bút mực, 1 bút chì và 1 chiếc thước kẻ:"
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "milo_thumbs_up",
                                "audio_cue": "gentle_pop_success",
                                "dopamine_points": 30
                        },
                        "hints": [
                                "Mở hộp bút đếm: 2 bút mực, 1 chì, 1 thước."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": true,
                                "feedback_on_error": "Kiểm tra đủ bút thước để mai làm bài tốt nhé!"
                        },
                        "is_final_step": false
                },
                {
                        "step_id": 4,
                        "badge": "Bình nước cá nhân",
                        "action_verb": "Bỏ_bình",
                        "atomic_instruction": "Cho bình nước đầy vào ngăn lưới bên hông.",
                        "text": "Cho bình nước đầy vào ngăn lưới bên hông.",
                        "type": "generic",
                        "ui_type": "checkbox",
                        "ui_data": {
                                "prompt_text": "Cho bình nước sạch đã rót đầy vào ngăn lưới bên hông balo:"
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 40
                        },
                        "hints": [
                                "Bình nước uống sạch để ở túi lưới bên sườn."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": true,
                                "feedback_on_error": "Nhớ mang theo bình nước để nạp năng lượng con nha!"
                        },
                        "is_final_step": true
                }
        ]
},

      // #29. hoat_dong_trai_nghiem (Grade 1): Gấp chăn gối gọn gàng sau khi thức dậy
      'chore_bed':   "id": "chore_bed",
        "grade": 1,
        "subject": "hoat_dong_trai_nghiem",
        "cat": "chore",
        "catName": "Thói Quen Buổi Sáng",
        "icon": "🛏️",
        "title": "Gấp chăn gối gọn gàng sau khi thức dậy",
        "island": "routine",
        "reward": 100,
        "stepSeconds": 60,
        "original_text": "Mỗi buổi sáng khi thức dậy, em hãy tự giác gấp chăn màn: giũ phẳng chăn, gấp đôi làm tư vuông vắn và đặt gối ngay ngắn ở đầu giường.",
        "final_answer": {
                "value": "Giường ngủ ngăn nắp gọn gàng",
                "unit": null,
                "normalized_display": "Giường ngủ ngăn nắp gọn gàng",
                "acceptable_variants": [
                        "gọn gàng",
                        "ngăn nắp",
                        "phẳng phiu"
                ]
        },
        "adhd_scaffolding_notes": {
                "working_memory_pitfall": "Mới ngủ dậy não bộ còn quán tính giấc ngủ (Sleep Inertia), dễ bỏ qua việc gấp chăn.",
                "executive_function_scaffolding": "3 động tác cơ học cực đơn giản: giũ -> gấp tư -> xếp gối.",
                "visual_or_concrete_aid": "Hoạt ảnh chăn gấp tự động thành hình chữ nhật phẳng phiu."
        },
        "steps": [
                {
                        "step_id": 1,
                        "badge": "Giũ phẳng chăn",
                        "action_verb": "Giũ",
                        "atomic_instruction": "Giũ nhẹ để chăn trải phẳng trên giường.",
                        "text": "Giũ nhẹ để chăn trải phẳng trên giường.",
                        "type": "generic",
                        "ui_type": "checkbox",
                        "ui_data": {
                                "prompt_text": "Cầm hai mép chăn giũ nhẹ để chăn trải phẳng trên giường:"
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "sparkle_star_01",
                                "audio_cue": "positive_bell_c6",
                                "dopamine_points": 25
                        },
                        "hints": [
                                "Cầm 2 góc chăn giũ cho phẳng phiu."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": true,
                                "feedback_on_error": "Giũ nhẹ chăn cho phẳng trước khi gấp con nhé!"
                        },
                        "is_final_step": false
                },
                {
                        "step_id": 2,
                        "badge": "Gấp chăn làm tư",
                        "action_verb": "Gấp",
                        "atomic_instruction": "Gấp đôi chăn rồi gấp lại thành hình vuông.",
                        "text": "Gấp đôi chăn rồi gấp lại thành hình vuông.",
                        "type": "generic",
                        "ui_type": "checkbox",
                        "ui_data": {
                                "prompt_text": "Gấp đôi chăn theo chiều dọc rồi gấp đôi lại thành hình vuông gọn:"
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "particle_burst_gold",
                                "audio_cue": "sparkle_ting_short",
                                "dopamine_points": 35
                        },
                        "hints": [
                                "Gấp đôi một lần, rồi gấp đôi thêm một lần nữa."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": true,
                                "feedback_on_error": "Gấp đôi rồi gấp tư thành hình vuông gọn gàng nha!"
                        },
                        "is_final_step": false
                },
                {
                        "step_id": 3,
                        "badge": "Đặt gối ngay ngắn",
                        "action_verb": "Đặt",
                        "atomic_instruction": "Vỗ nhẹ gối và đặt sát đầu giường.",
                        "text": "Vỗ nhẹ gối và đặt sát đầu giường.",
                        "type": "generic",
                        "ui_type": "checkbox",
                        "ui_data": {
                                "prompt_text": "Vỗ nhẹ gối và đặt ngay ngắn sát đầu giường:"
                        },
                        "duration_sec": 60,
                        "immediate_reinforcer": {
                                "visual_asset": "confetti_cannon",
                                "audio_cue": "harp_glissando_soft",
                                "dopamine_points": 40
                        },
                        "hints": [
                                "Vỗ nhẹ gối và xếp sát đầu giường nhé."
                        ],
                        "success_criteria": {
                                "evaluation_type": "exact_match",
                                "expected_answer": true,
                                "feedback_on_error": "Đặt chiếc gối êm ái sát đầu giường nào!"
                        },
                        "is_final_step": true
                }
        ]
}

      // Backward Compatibility Alias:
      'math_garden': null // Linked dynamically below
    };
    taskDatabase['math_garden'] = taskDatabase['G1_MATH_01']; // Alias for legacy references